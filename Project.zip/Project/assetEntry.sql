﻿CREATE TABLE [dbo].[AssetSoftwareEntry] (
    [User Name]               NVARCHAR (50)  NOT NULL,
    [Software Type]           NVARCHAR (50)  NOT NULL,
    [Assets Description]      NVARCHAR (MAX) NOT NULL,
    [Qty]                     NVARCHAR (50)  NOT NULL,
    [Supplier]                NVARCHAR (50)  NOT NULL,
    [Authorization Number]    NVARCHAR (50)  NOT NULL,
    [Asset Number]            NVARCHAR (50)  NOT NULL,
    [Po Number]               NVARCHAR (50)  NOT NULL,
    [Inv Number]              NVARCHAR (50)  NOT NULL,
    [Software Assurance Date] DATE           NOT NULL,
    [License Type]            NVARCHAR (50)  NOT NULL,
    [Asset Date]              DATE           NOT NULL,
    [Po Date]                 DATE           NOT NULL,
    [Inv Date]                DATE           NOT NULL,
    PRIMARY KEY CLUSTERED ([Authorization Number] ASC)
);

