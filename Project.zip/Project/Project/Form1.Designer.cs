﻿namespace Assets_Software_Entry
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dateTimePicker5 = new System.Windows.Forms.DateTimePicker();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.button8 = new System.Windows.Forms.Button();
            this.assetSoftwareEntry = new Assets_Software_Entry.AssetSoftwareEntry();
            this.assetSoftwareEntryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.assetSoftwareEntryTableAdapter = new Assets_Software_Entry.AssetSoftwareEntryTableAdapters.AssetSoftwareEntryTableAdapter();
            this.tableAdapterManager = new Assets_Software_Entry.AssetSoftwareEntryTableAdapters.TableAdapterManager();
            this.assetSoftwareEntryDataGridView = new System.Windows.Forms.DataGridView();
            this.srNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.companyNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.softwareTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.assetsDescriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supplierDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.authorizationNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.assetNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.poNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.softwareAssuranceDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.licenseTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.poDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.remarksDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.licenseNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.licenseDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.assetSoftwareEntryBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.finalDSBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.finalDS = new Assets_Software_Entry.FinalDS();
            this.assetSoftwareEntryBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.softEntryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.softEntry = new Assets_Software_Entry.softEntry();
            this.assetSoftwareEntryBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.entriesSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.entriesSet = new Assets_Software_Entry.EntriesSet();
            this.assetSoftwareEntryBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.assetSoftwareEntryDataSet3BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.assetSoftwareEntryDataSet3 = new Assets_Software_Entry.AssetSoftwareEntryDataSet3();
            this.assetSoftwareEntryBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.assetSoftwareEntryDataSet2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.assetSoftwareEntryDataSet2 = new Assets_Software_Entry.AssetSoftwareEntryDataSet2();
            this.assetSoftwareEntryTableAdapter1 = new Assets_Software_Entry.AssetSoftwareEntryDataSet2TableAdapters.AssetSoftwareEntryTableAdapter();
            this.assetSoftwareEntryTableAdapter2 = new Assets_Software_Entry.AssetSoftwareEntryDataSet3TableAdapters.AssetSoftwareEntryTableAdapter();
            this.button3 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.assetSoftwareEntryTableAdapter3 = new Assets_Software_Entry.EntriesSetTableAdapters.AssetSoftwareEntryTableAdapter();
            this.assetSoftwareEntryTableAdapter4 = new Assets_Software_Entry.softEntryTableAdapters.AssetSoftwareEntryTableAdapter();
            this.label20 = new System.Windows.Forms.Label();
            this.assetSoftwareEntryTableAdapter5 = new Assets_Software_Entry.FinalDSTableAdapters.AssetSoftwareEntryTableAdapter();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntry)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryBindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalDSBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalDS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.softEntryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.softEntry)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.entriesSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.entriesSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryDataSet3BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryDataSet2BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryDataSet2)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(21, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 18);
            this.label3.TabIndex = 2;
            this.label3.Text = "Software Type";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Location = new System.Drawing.Point(21, 163);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(151, 18);
            this.label4.TabIndex = 3;
            this.label4.Text = "Product Description";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Location = new System.Drawing.Point(21, 225);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 18);
            this.label5.TabIndex = 4;
            this.label5.Text = "Qty";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label6.Location = new System.Drawing.Point(906, 96);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 18);
            this.label6.TabIndex = 5;
            this.label6.Text = "Supplier";
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label8.Location = new System.Drawing.Point(906, 176);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 18);
            this.label8.TabIndex = 9;
            this.label8.Text = "Inv Date";
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.Location = new System.Drawing.Point(906, 136);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 18);
            this.label9.TabIndex = 8;
            this.label9.Text = "Po Date";
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label10.Location = new System.Drawing.Point(906, 18);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(101, 18);
            this.label10.TabIndex = 7;
            this.label10.Text = "License Type";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label12.Location = new System.Drawing.Point(445, 215);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(186, 18);
            this.label12.TabIndex = 15;
            this.label12.Text = "Software Assurance Date";
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label13.Location = new System.Drawing.Point(445, 173);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(115, 18);
            this.label13.TabIndex = 14;
            this.label13.Text = "Vendor Inv No.";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label14.Location = new System.Drawing.Point(445, 134);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(54, 18);
            this.label14.TabIndex = 13;
            this.label14.Text = "Po No.";
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label15.Location = new System.Drawing.Point(445, 93);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(167, 18);
            this.label15.TabIndex = 12;
            this.label15.Text = "Authorization Number";
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label16.Location = new System.Drawing.Point(445, 14);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(104, 18);
            this.label16.TabIndex = 11;
            this.label16.Text = "Part  Number";
            // 
            // textBox7
            // 
            this.textBox7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox7.Location = new System.Drawing.Point(737, 171);
            this.textBox7.MaximumSize = new System.Drawing.Size(172, 20);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(136, 20);
            this.textBox7.TabIndex = 12;
            this.textBox7.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            this.textBox7.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox2_KeyDown);
            // 
            // textBox5
            // 
            this.textBox5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox5.Location = new System.Drawing.Point(737, 132);
            this.textBox5.MaximumSize = new System.Drawing.Size(172, 20);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(136, 20);
            this.textBox5.TabIndex = 9;
            this.textBox5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox4_KeyDown);
            // 
            // textBox2
            // 
            this.textBox2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox2.Location = new System.Drawing.Point(737, 12);
            this.textBox2.MaximumSize = new System.Drawing.Size(172, 20);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(136, 20);
            this.textBox2.TabIndex = 2;
            this.textBox2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox5_KeyDown);
            // 
            // textBox4
            // 
            this.textBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox4.Location = new System.Drawing.Point(1046, 94);
            this.textBox4.MaximumSize = new System.Drawing.Size(172, 20);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(133, 20);
            this.textBox4.TabIndex = 8;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            this.textBox4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox6_KeyDown);
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(219, 223);
            this.textBox8.MaximumSize = new System.Drawing.Size(172, 20);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(136, 20);
            this.textBox8.TabIndex = 14;
            this.textBox8.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox7_KeyDown);
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(219, 128);
            this.textBox6.MaximumSize = new System.Drawing.Size(270, 80);
            this.textBox6.Multiline = true;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(199, 80);
            this.textBox6.TabIndex = 11;
            this.textBox6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox8_KeyDown);
            // 
            // comboBox2
            // 
            this.comboBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox2.AutoCompleteCustomSource.AddRange(new string[] {
            "Subscription",
            "Yearly"});
            this.comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Perpetual",
            "Subscription"});
            this.comboBox2.Location = new System.Drawing.Point(1046, 15);
            this.comboBox2.MaximumSize = new System.Drawing.Size(172, 0);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(133, 21);
            this.comboBox2.TabIndex = 3;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // textBox3
            // 
            this.textBox3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox3.Location = new System.Drawing.Point(737, 91);
            this.textBox3.MaximumSize = new System.Drawing.Size(172, 20);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(136, 20);
            this.textBox3.TabIndex = 7;
            this.textBox3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyDown);
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dateTimePicker3.Location = new System.Drawing.Point(737, 213);
            this.dateTimePicker3.MaximumSize = new System.Drawing.Size(172, 20);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dateTimePicker3.Size = new System.Drawing.Size(136, 20);
            this.dateTimePicker3.TabIndex = 15;
            this.dateTimePicker3.Value = new System.DateTime(2020, 9, 26, 0, 0, 0, 0);
            this.dateTimePicker3.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.dateTimePicker2.Location = new System.Drawing.Point(1046, 174);
            this.dateTimePicker2.MaximumSize = new System.Drawing.Size(172, 20);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(133, 20);
            this.dateTimePicker2.TabIndex = 13;
            this.dateTimePicker2.ValueChanged += new System.EventHandler(this.dateTimePicker2_ValueChanged);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.dateTimePicker1.Location = new System.Drawing.Point(1046, 134);
            this.dateTimePicker1.MaximumSize = new System.Drawing.Size(172, 20);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(133, 20);
            this.dateTimePicker1.TabIndex = 10;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker3_ValueChanged);
            // 
            // button4
            // 
            this.button4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button4.BackgroundImage")));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button4.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(691, 385);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(128, 36);
            this.button4.TabIndex = 32;
            this.button4.Text = "Save";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button5.BackgroundImage")));
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button5.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(1093, 385);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(128, 36);
            this.button5.TabIndex = 19;
            this.button5.Text = "Edit Entries";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button6.BackgroundImage")));
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button6.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(959, 385);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(128, 36);
            this.button6.TabIndex = 18;
            this.button6.Text = "View Entries";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button7.BackgroundImage")));
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button7.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(825, 385);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(128, 36);
            this.button7.TabIndex = 17;
            this.button7.Text = "New";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.CausesValidation = false;
            this.panel2.Controls.Add(this.dateTimePicker5);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.textBox13);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.textBox11);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.checkedListBox1);
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.textBox6);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.textBox4);
            this.panel2.Controls.Add(this.textBox8);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.dateTimePicker1);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.dateTimePicker2);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.comboBox2);
            this.panel2.Controls.Add(this.dateTimePicker3);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.textBox3);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.textBox2);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.textBox5);
            this.panel2.Controls.Add(this.textBox7);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Location = new System.Drawing.Point(17, 66);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1206, 313);
            this.panel2.TabIndex = 36;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // dateTimePicker5
            // 
            this.dateTimePicker5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.dateTimePicker5.Location = new System.Drawing.Point(1046, 55);
            this.dateTimePicker5.MaximumSize = new System.Drawing.Size(172, 20);
            this.dateTimePicker5.Name = "dateTimePicker5";
            this.dateTimePicker5.Size = new System.Drawing.Size(133, 20);
            this.dateTimePicker5.TabIndex = 5;
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label18.Location = new System.Drawing.Point(906, 57);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(100, 18);
            this.label18.TabIndex = 62;
            this.label18.Text = "License Date";
            // 
            // label19
            // 
            this.label19.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label19.Location = new System.Drawing.Point(445, 54);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(123, 18);
            this.label19.TabIndex = 65;
            this.label19.Text = "License Number";
            // 
            // textBox13
            // 
            this.textBox13.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox13.Location = new System.Drawing.Point(737, 52);
            this.textBox13.MaximumSize = new System.Drawing.Size(172, 20);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(136, 20);
            this.textBox13.TabIndex = 4;
            // 
            // label17
            // 
            this.label17.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label17.Location = new System.Drawing.Point(906, 215);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(71, 18);
            this.label17.TabIndex = 60;
            this.label17.Text = "Remarks";
            // 
            // textBox11
            // 
            this.textBox11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox11.Location = new System.Drawing.Point(1046, 213);
            this.textBox11.MaximumSize = new System.Drawing.Size(172, 20);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(133, 20);
            this.textBox11.TabIndex = 61;
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.CheckOnClick = true;
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Items.AddRange(new object[] {
            "OFFICE 365",
            "ADOBE",
            "AUTOCAD",
            "CORAL DRAW",
            "WINDOWS 10",
            "WIN CAL DEVICE",
            "WPS Office",
            "Solidworks Pro"});
            this.checkedListBox1.Location = new System.Drawing.Point(219, 39);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(136, 49);
            this.checkedListBox1.TabIndex = 58;
            this.checkedListBox1.SelectedIndexChanged += new System.EventHandler(this.checkedListBox1_SelectedIndexChanged);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(219, 13);
            this.textBox1.MaximumSize = new System.Drawing.Size(172, 20);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(136, 20);
            this.textBox1.TabIndex = 1;
            this.textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyDown_1);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label11.Location = new System.Drawing.Point(19, 11);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(119, 18);
            this.label11.TabIndex = 6;
            this.label11.Text = "Company Name";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.textBox10);
            this.groupBox1.Controls.Add(this.dateTimePicker4);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox1.Location = new System.Drawing.Point(3, 94);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(360, 69);
            this.groupBox1.TabIndex = 59;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ADOBE";
            this.groupBox1.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(15, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 18);
            this.label2.TabIndex = 7;
            this.label2.Text = "VIP No.";
            this.label2.Visible = false;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(216, 14);
            this.textBox10.MaximumSize = new System.Drawing.Size(172, 20);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(136, 20);
            this.textBox10.TabIndex = 59;
            this.textBox10.Visible = false;
            this.textBox10.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox10_KeyDown);
            // 
            // dateTimePicker4
            // 
            this.dateTimePicker4.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker4.Location = new System.Drawing.Point(215, 40);
            this.dateTimePicker4.MaximumSize = new System.Drawing.Size(172, 20);
            this.dateTimePicker4.Name = "dateTimePicker4";
            this.dateTimePicker4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dateTimePicker4.Size = new System.Drawing.Size(136, 20);
            this.dateTimePicker4.TabIndex = 60;
            this.dateTimePicker4.Value = new System.DateTime(2020, 9, 26, 0, 0, 0, 0);
            this.dateTimePicker4.Visible = false;
            this.dateTimePicker4.ValueChanged += new System.EventHandler(this.dateTimePicker4_ValueChanged_1);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label7.Location = new System.Drawing.Point(15, 34);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(133, 18);
            this.label7.TabIndex = 16;
            this.label7.Text = "Anniversary Date";
            this.label7.Visible = false;
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button2.BackgroundImage")));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(691, 385);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(128, 36);
            this.button2.TabIndex = 16;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(1082, 25);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(128, 36);
            this.button1.TabIndex = 51;
            this.button1.Text = "Reset";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // comboBox4
            // 
            this.comboBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "Company Name",
            "Authorization Number",
            "Part Number"});
            this.comboBox4.Location = new System.Drawing.Point(558, 35);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(250, 21);
            this.comboBox4.TabIndex = 50;
            this.comboBox4.Visible = false;
            this.comboBox4.SelectedIndexChanged += new System.EventHandler(this.comboBox4_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(554, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 23);
            this.label1.TabIndex = 49;
            this.label1.Text = "Search for :";
            this.label1.Visible = false;
            // 
            // textBox9
            // 
            this.textBox9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox9.Location = new System.Drawing.Point(558, 35);
            this.textBox9.MaximumSize = new System.Drawing.Size(250, 22);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(250, 20);
            this.textBox9.TabIndex = 51;
            this.textBox9.Visible = false;
            // 
            // button8
            // 
            this.button8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button8.BackgroundImage")));
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button8.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(814, 25);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(128, 36);
            this.button8.TabIndex = 38;
            this.button8.Text = "Search";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Visible = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // assetSoftwareEntry
            // 
            this.assetSoftwareEntry.DataSetName = "AssetSoftwareEntry";
            this.assetSoftwareEntry.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // assetSoftwareEntryBindingSource
            // 
            this.assetSoftwareEntryBindingSource.DataMember = "AssetSoftwareEntry";
            this.assetSoftwareEntryBindingSource.DataSource = this.assetSoftwareEntry;
            // 
            // assetSoftwareEntryTableAdapter
            // 
            this.assetSoftwareEntryTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AssetSoftwareEntryTableAdapter = this.assetSoftwareEntryTableAdapter;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = Assets_Software_Entry.AssetSoftwareEntryTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.usersTableAdapter = null;
            // 
            // assetSoftwareEntryDataGridView
            // 
            this.assetSoftwareEntryDataGridView.AllowUserToAddRows = false;
            this.assetSoftwareEntryDataGridView.AllowUserToDeleteRows = false;
            this.assetSoftwareEntryDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.assetSoftwareEntryDataGridView.AutoGenerateColumns = false;
            this.assetSoftwareEntryDataGridView.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.assetSoftwareEntryDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.assetSoftwareEntryDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.srNoDataGridViewTextBoxColumn,
            this.companyNameDataGridViewTextBoxColumn,
            this.softwareTypeDataGridViewTextBoxColumn,
            this.assetsDescriptionDataGridViewTextBoxColumn,
            this.qtyDataGridViewTextBoxColumn,
            this.supplierDataGridViewTextBoxColumn,
            this.authorizationNumberDataGridViewTextBoxColumn,
            this.assetNumberDataGridViewTextBoxColumn,
            this.poNumberDataGridViewTextBoxColumn,
            this.invNumberDataGridViewTextBoxColumn,
            this.softwareAssuranceDateDataGridViewTextBoxColumn,
            this.licenseTypeDataGridViewTextBoxColumn,
            this.poDateDataGridViewTextBoxColumn,
            this.invDateDataGridViewTextBoxColumn,
            this.remarksDataGridViewTextBoxColumn,
            this.licenseNumberDataGridViewTextBoxColumn,
            this.licenseDateDataGridViewTextBoxColumn});
            this.assetSoftwareEntryDataGridView.DataSource = this.assetSoftwareEntryBindingSource5;
            this.assetSoftwareEntryDataGridView.Location = new System.Drawing.Point(7, 439);
            this.assetSoftwareEntryDataGridView.Name = "assetSoftwareEntryDataGridView";
            this.assetSoftwareEntryDataGridView.ReadOnly = true;
            this.assetSoftwareEntryDataGridView.Size = new System.Drawing.Size(1216, 176);
            this.assetSoftwareEntryDataGridView.TabIndex = 16;
            this.assetSoftwareEntryDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.assetSoftwareEntryDataGridView_CellContentClick);
            // 
            // srNoDataGridViewTextBoxColumn
            // 
            this.srNoDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.srNoDataGridViewTextBoxColumn.DataPropertyName = "Sr_ No_";
            this.srNoDataGridViewTextBoxColumn.HeaderText = "Sr_ No_";
            this.srNoDataGridViewTextBoxColumn.Name = "srNoDataGridViewTextBoxColumn";
            this.srNoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // companyNameDataGridViewTextBoxColumn
            // 
            this.companyNameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.companyNameDataGridViewTextBoxColumn.DataPropertyName = "Company Name";
            this.companyNameDataGridViewTextBoxColumn.HeaderText = "Company Name";
            this.companyNameDataGridViewTextBoxColumn.Name = "companyNameDataGridViewTextBoxColumn";
            this.companyNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // softwareTypeDataGridViewTextBoxColumn
            // 
            this.softwareTypeDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.softwareTypeDataGridViewTextBoxColumn.DataPropertyName = "Software Type";
            this.softwareTypeDataGridViewTextBoxColumn.HeaderText = "Software Type";
            this.softwareTypeDataGridViewTextBoxColumn.Name = "softwareTypeDataGridViewTextBoxColumn";
            this.softwareTypeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // assetsDescriptionDataGridViewTextBoxColumn
            // 
            this.assetsDescriptionDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.assetsDescriptionDataGridViewTextBoxColumn.DataPropertyName = "Assets Description";
            this.assetsDescriptionDataGridViewTextBoxColumn.HeaderText = "Product Description";
            this.assetsDescriptionDataGridViewTextBoxColumn.Name = "assetsDescriptionDataGridViewTextBoxColumn";
            this.assetsDescriptionDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // qtyDataGridViewTextBoxColumn
            // 
            this.qtyDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.qtyDataGridViewTextBoxColumn.DataPropertyName = "Qty";
            this.qtyDataGridViewTextBoxColumn.HeaderText = "Qty";
            this.qtyDataGridViewTextBoxColumn.Name = "qtyDataGridViewTextBoxColumn";
            this.qtyDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // supplierDataGridViewTextBoxColumn
            // 
            this.supplierDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.supplierDataGridViewTextBoxColumn.DataPropertyName = "Supplier";
            this.supplierDataGridViewTextBoxColumn.HeaderText = "Supplier";
            this.supplierDataGridViewTextBoxColumn.Name = "supplierDataGridViewTextBoxColumn";
            this.supplierDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // authorizationNumberDataGridViewTextBoxColumn
            // 
            this.authorizationNumberDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.authorizationNumberDataGridViewTextBoxColumn.DataPropertyName = "Authorization Number";
            this.authorizationNumberDataGridViewTextBoxColumn.HeaderText = "Authorization Number";
            this.authorizationNumberDataGridViewTextBoxColumn.Name = "authorizationNumberDataGridViewTextBoxColumn";
            this.authorizationNumberDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // assetNumberDataGridViewTextBoxColumn
            // 
            this.assetNumberDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.assetNumberDataGridViewTextBoxColumn.DataPropertyName = "Asset Number";
            this.assetNumberDataGridViewTextBoxColumn.HeaderText = "Part Number";
            this.assetNumberDataGridViewTextBoxColumn.Name = "assetNumberDataGridViewTextBoxColumn";
            this.assetNumberDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // poNumberDataGridViewTextBoxColumn
            // 
            this.poNumberDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.poNumberDataGridViewTextBoxColumn.DataPropertyName = "Po Number";
            this.poNumberDataGridViewTextBoxColumn.HeaderText = "Po Number";
            this.poNumberDataGridViewTextBoxColumn.Name = "poNumberDataGridViewTextBoxColumn";
            this.poNumberDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // invNumberDataGridViewTextBoxColumn
            // 
            this.invNumberDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.invNumberDataGridViewTextBoxColumn.DataPropertyName = "Inv Number";
            this.invNumberDataGridViewTextBoxColumn.HeaderText = "Vendor Inv Number";
            this.invNumberDataGridViewTextBoxColumn.Name = "invNumberDataGridViewTextBoxColumn";
            this.invNumberDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // softwareAssuranceDateDataGridViewTextBoxColumn
            // 
            this.softwareAssuranceDateDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.softwareAssuranceDateDataGridViewTextBoxColumn.DataPropertyName = "Software Assurance Date";
            this.softwareAssuranceDateDataGridViewTextBoxColumn.HeaderText = "Software Assurance Date";
            this.softwareAssuranceDateDataGridViewTextBoxColumn.Name = "softwareAssuranceDateDataGridViewTextBoxColumn";
            this.softwareAssuranceDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // licenseTypeDataGridViewTextBoxColumn
            // 
            this.licenseTypeDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.licenseTypeDataGridViewTextBoxColumn.DataPropertyName = "License Type";
            this.licenseTypeDataGridViewTextBoxColumn.HeaderText = "License Type";
            this.licenseTypeDataGridViewTextBoxColumn.Name = "licenseTypeDataGridViewTextBoxColumn";
            this.licenseTypeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // poDateDataGridViewTextBoxColumn
            // 
            this.poDateDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.poDateDataGridViewTextBoxColumn.DataPropertyName = "Po Date";
            this.poDateDataGridViewTextBoxColumn.HeaderText = "Po Date";
            this.poDateDataGridViewTextBoxColumn.Name = "poDateDataGridViewTextBoxColumn";
            this.poDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // invDateDataGridViewTextBoxColumn
            // 
            this.invDateDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.invDateDataGridViewTextBoxColumn.DataPropertyName = "Inv Date";
            this.invDateDataGridViewTextBoxColumn.HeaderText = "Inv Date";
            this.invDateDataGridViewTextBoxColumn.Name = "invDateDataGridViewTextBoxColumn";
            this.invDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // remarksDataGridViewTextBoxColumn
            // 
            this.remarksDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.remarksDataGridViewTextBoxColumn.DataPropertyName = "Remarks";
            this.remarksDataGridViewTextBoxColumn.HeaderText = "Remarks";
            this.remarksDataGridViewTextBoxColumn.Name = "remarksDataGridViewTextBoxColumn";
            this.remarksDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // licenseNumberDataGridViewTextBoxColumn
            // 
            this.licenseNumberDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.licenseNumberDataGridViewTextBoxColumn.DataPropertyName = "License Number";
            this.licenseNumberDataGridViewTextBoxColumn.HeaderText = "License Number";
            this.licenseNumberDataGridViewTextBoxColumn.Name = "licenseNumberDataGridViewTextBoxColumn";
            this.licenseNumberDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // licenseDateDataGridViewTextBoxColumn
            // 
            this.licenseDateDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.licenseDateDataGridViewTextBoxColumn.DataPropertyName = "License Date";
            this.licenseDateDataGridViewTextBoxColumn.HeaderText = "License Date";
            this.licenseDateDataGridViewTextBoxColumn.Name = "licenseDateDataGridViewTextBoxColumn";
            this.licenseDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // assetSoftwareEntryBindingSource5
            // 
            this.assetSoftwareEntryBindingSource5.DataMember = "AssetSoftwareEntry";
            this.assetSoftwareEntryBindingSource5.DataSource = this.finalDSBindingSource;
            // 
            // finalDSBindingSource
            // 
            this.finalDSBindingSource.DataSource = this.finalDS;
            this.finalDSBindingSource.Position = 0;
            // 
            // finalDS
            // 
            this.finalDS.DataSetName = "FinalDS";
            this.finalDS.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // assetSoftwareEntryBindingSource4
            // 
            this.assetSoftwareEntryBindingSource4.DataMember = "AssetSoftwareEntry";
            this.assetSoftwareEntryBindingSource4.DataSource = this.softEntryBindingSource;
            // 
            // softEntryBindingSource
            // 
            this.softEntryBindingSource.DataSource = this.softEntry;
            this.softEntryBindingSource.Position = 0;
            // 
            // softEntry
            // 
            this.softEntry.DataSetName = "softEntry";
            this.softEntry.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // assetSoftwareEntryBindingSource3
            // 
            this.assetSoftwareEntryBindingSource3.DataMember = "AssetSoftwareEntry";
            this.assetSoftwareEntryBindingSource3.DataSource = this.entriesSetBindingSource;
            // 
            // entriesSetBindingSource
            // 
            this.entriesSetBindingSource.DataSource = this.entriesSet;
            this.entriesSetBindingSource.Position = 0;
            // 
            // entriesSet
            // 
            this.entriesSet.DataSetName = "EntriesSet";
            this.entriesSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // assetSoftwareEntryBindingSource2
            // 
            this.assetSoftwareEntryBindingSource2.DataMember = "AssetSoftwareEntry";
            this.assetSoftwareEntryBindingSource2.DataSource = this.assetSoftwareEntryDataSet3BindingSource;
            // 
            // assetSoftwareEntryDataSet3BindingSource
            // 
            this.assetSoftwareEntryDataSet3BindingSource.DataSource = this.assetSoftwareEntryDataSet3;
            this.assetSoftwareEntryDataSet3BindingSource.Position = 0;
            // 
            // assetSoftwareEntryDataSet3
            // 
            this.assetSoftwareEntryDataSet3.DataSetName = "AssetSoftwareEntryDataSet3";
            this.assetSoftwareEntryDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // assetSoftwareEntryBindingSource1
            // 
            this.assetSoftwareEntryBindingSource1.DataMember = "AssetSoftwareEntry";
            this.assetSoftwareEntryBindingSource1.DataSource = this.assetSoftwareEntryDataSet2BindingSource;
            // 
            // assetSoftwareEntryDataSet2BindingSource
            // 
            this.assetSoftwareEntryDataSet2BindingSource.DataSource = this.assetSoftwareEntryDataSet2;
            this.assetSoftwareEntryDataSet2BindingSource.Position = 0;
            // 
            // assetSoftwareEntryDataSet2
            // 
            this.assetSoftwareEntryDataSet2.DataSetName = "AssetSoftwareEntryDataSet2";
            this.assetSoftwareEntryDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // assetSoftwareEntryTableAdapter1
            // 
            this.assetSoftwareEntryTableAdapter1.ClearBeforeFill = true;
            // 
            // assetSoftwareEntryTableAdapter2
            // 
            this.assetSoftwareEntryTableAdapter2.ClearBeforeFill = true;
            // 
            // button3
            // 
            this.button3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button3.BackgroundImage")));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.Location = new System.Drawing.Point(-3, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(64, 52);
            this.button3.TabIndex = 52;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button9
            // 
            this.button9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button9.BackgroundImage")));
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button9.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(948, 25);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(128, 36);
            this.button9.TabIndex = 76;
            this.button9.Text = "Delete Entry";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Visible = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // assetSoftwareEntryTableAdapter3
            // 
            this.assetSoftwareEntryTableAdapter3.ClearBeforeFill = true;
            // 
            // assetSoftwareEntryTableAdapter4
            // 
            this.assetSoftwareEntryTableAdapter4.ClearBeforeFill = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label20.Location = new System.Drawing.Point(14, 418);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(202, 18);
            this.label20.TabIndex = 77;
            this.label20.Text = "Developed by CKT Infotech";
            // 
            // assetSoftwareEntryTableAdapter5
            // 
            this.assetSoftwareEntryTableAdapter5.ClearBeforeFill = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(35)))), ((int)(((byte)(35)))));
            this.ClientSize = new System.Drawing.Size(1230, 618);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.assetSoftwareEntryDataGridView);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.panel2);
            this.MinimumSize = new System.Drawing.Size(1246, 657);
            this.Name = "Form1";
            this.Text = "AssetsSoftware Entry";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntry)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryBindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalDSBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalDS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.softEntryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.softEntry)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.entriesSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.entriesSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryDataSet3BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryDataSet2BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryDataSet2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Button button8;
        private AssetSoftwareEntry assetSoftwareEntry;
        private System.Windows.Forms.BindingSource assetSoftwareEntryBindingSource;
        private AssetSoftwareEntryTableAdapters.AssetSoftwareEntryTableAdapter assetSoftwareEntryTableAdapter;
        private AssetSoftwareEntryTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView assetSoftwareEntryDataGridView;
        private System.Windows.Forms.BindingSource assetSoftwareEntryDataSet2BindingSource;
        private AssetSoftwareEntryDataSet2 assetSoftwareEntryDataSet2;
        private System.Windows.Forms.BindingSource assetSoftwareEntryBindingSource1;
        private AssetSoftwareEntryDataSet2TableAdapters.AssetSoftwareEntryTableAdapter assetSoftwareEntryTableAdapter1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.DateTimePicker dateTimePicker4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.BindingSource assetSoftwareEntryDataSet3BindingSource;
        private AssetSoftwareEntryDataSet3 assetSoftwareEntryDataSet3;
        private System.Windows.Forms.BindingSource assetSoftwareEntryBindingSource2;
        private AssetSoftwareEntryDataSet3TableAdapters.AssetSoftwareEntryTableAdapter assetSoftwareEntryTableAdapter2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.BindingSource entriesSetBindingSource;
        private EntriesSet entriesSet;
        private System.Windows.Forms.BindingSource assetSoftwareEntryBindingSource3;
        private EntriesSetTableAdapters.AssetSoftwareEntryTableAdapter assetSoftwareEntryTableAdapter3;
        private System.Windows.Forms.DateTimePicker dateTimePicker5;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.BindingSource softEntryBindingSource;
        private softEntry softEntry;
        private System.Windows.Forms.BindingSource assetSoftwareEntryBindingSource4;
        private softEntryTableAdapters.AssetSoftwareEntryTableAdapter assetSoftwareEntryTableAdapter4;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.BindingSource finalDSBindingSource;
        private FinalDS finalDS;
        private System.Windows.Forms.BindingSource assetSoftwareEntryBindingSource5;
        private FinalDSTableAdapters.AssetSoftwareEntryTableAdapter assetSoftwareEntryTableAdapter5;
        private System.Windows.Forms.DataGridViewTextBoxColumn srNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn companyNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn softwareTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn assetsDescriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn supplierDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn authorizationNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn assetNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn poNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn invNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn softwareAssuranceDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn licenseTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn poDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn invDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn remarksDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn licenseNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn licenseDateDataGridViewTextBoxColumn;
    }
}

