﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace Assets_Software_Entry
{
    public partial class ReportH : Form
    {
        ReportDocument rep = new ReportDocument();
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\AssetSoftwareEntry.mdf;Integrated Security=True";
        public ReportH()
        {
            InitializeComponent();
        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {

        }

        private void ReportH_Load(object sender, EventArgs e)
        {
            string filename = @"CrystalReport2.rpt";
            string filePath = AppDomain.CurrentDomain.BaseDirectory + filename;
            rep.Load(@""+ filePath + "");

            TableLogOnInfos tableLogOnInfos = new TableLogOnInfos();
            TableLogOnInfo tableLogOnInfo = new TableLogOnInfo();
            ConnectionInfo connectionInfo = new ConnectionInfo();
            Tables tables;

            connectionInfo.ServerName = @"(LocalDB)\MSSQLLocalDB";
            connectionInfo.DatabaseName = "AssetSoftwareEntry";
            connectionInfo.UserID = @"LAPTOP-MCM75Q33\karan";
            connectionInfo.Password = "";

            tables = rep.Database.Tables;

            foreach (CrystalDecisions.CrystalReports.Engine.Table table in tables)
            {
                tableLogOnInfo = table.LogOnInfo;
                tableLogOnInfo.ConnectionInfo = connectionInfo;
                table.ApplyLogOnInfo(tableLogOnInfo);
            }

            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter("select * from HardwareEntry", con);
            DataSet ds = new System.Data.DataSet();
            sda.Fill(ds, "HardwareEntry");
            rep.SetDataSource(ds);
            crystalReportViewer1.ReportSource = rep;
        }
    }
}
