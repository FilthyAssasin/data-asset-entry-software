﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace Assets_Software_Entry
{
    
    public partial class HardwareEntry : Form
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\AssetSoftwareEntry.mdf;Integrated Security=True";
        public HardwareEntry()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;

        }

        private void hardwareEntryBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
        }

        private void HardwareEntry_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'finalDS.HardwareEntry' table. You can move, or remove it, as needed.
            this.hardwareEntryTableAdapter5.Fill(this.finalDS.HardwareEntry);
        }

        private void hardwareEntryDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        public void textboxchange()
        {
            SendKeys.SendWait("{TAB }");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            {
                SqlConnection con = new SqlConnection(connectionString);
                string sTypeEntry = "";
                foreach(string s in checkedListBox1.CheckedItems)
                {
                    if(s == "ADOBE")
                    {
                        sTypeEntry = sTypeEntry + s + "_" + textBox10.Text.Trim() + "_" + dateTimePicker4.Value.ToString("dd-MM-yyyy") + ",";
                    }
                    else
                    {
                        sTypeEntry = sTypeEntry + s + ",";
                    }
                }
                SqlCommand cmd = new SqlCommand("INSERT INTO HardwareEntry([Company Name],[Username],[PC Type],[Make and Model],[System Config],[Monitor],[Printer],[O/S],[IP Address],[Asset ID],[Software Type],[Department],[Location],[Printer Number],[Remarks]) VALUES ('" + textBox5.Text.Trim() + "','" + textBox1.Text.Trim() + "','" + comboBox1.SelectedItem + "','" + comboBox2.SelectedItem + "','" + textBox2.Text.Trim() + "','" + textBox8.Text.Trim() + "','" + comboBox4.SelectedItem + "','" + comboBox5.SelectedItem + "','" + textBox3.Text.Trim() 
                    + "','" + textBox4.Text.Trim() + "','" + sTypeEntry + "','" + comboBox8.SelectedItem + "','" + comboBox7.SelectedItem + "','" + textBox6.Text.Trim() + "','" + textBox7.Text.Trim() +"')", con);
                cmd.CommandTimeout = 60;

                try
                {
                    con.Open();
                    Clear();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Successfully Submitted");
                }
                catch (Exception ec)
                {
                    MessageBox.Show(ec.Message);
                    MessageBox.Show("error");
                    con.Close();

                }

                DataTable dt = this.hardwareEntryTableAdapter5.GetData();
                hardwareEntryDataGridView.DataSource = dt;

            }
        }
        private void Clear()
        {
            textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = textBox10.Text = textBox5.Text = textBox6.Text = textBox7.Text = "";
            
            comboBox1.Text = comboBox2.Text = textBox8.Text = comboBox4.Text = comboBox5.Text = comboBox7.Text = comboBox8.Text = "";
            for(int i = 0; i < checkedListBox1.Items.Count; i++)
            {
                checkedListBox1.SetItemChecked(i, false);
            }

            label8.Visible = false;
            textBox10.Visible = false;
            label7.Visible = false;
            dateTimePicker4.Visible = false;
            groupBox1.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            {
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();

                SqlCommand cmd = new SqlCommand("Update HardwareEntry set [Company Name] = @CompanyName, [Username] = @Username, [PC Type] = @PCType, [Make and Model] = @MakeandModel, [System Config] = @SystemConfig, [Monitor] = @Monitor, [Printer] = @Printer, [O/S] = @OS, [IP Address] = @IPAddress, [Asset ID] = @AssetID, [Software Type] = @SoftwareType, [Department] = @Department, [Location] = @Location, [Printer Number] = @PrinterNumber, [Remarks] = @Remarks where [" + label1.Text + "] = @Uname", con);

                cmd.Parameters.AddWithValue("@CompanyName", textBox5.Text.Trim());
                cmd.Parameters.AddWithValue("@Username", textBox1.Text.Trim());
                cmd.Parameters.AddWithValue("@PCType", (comboBox1.SelectedItem != null) ? comboBox1.SelectedItem : "");
                cmd.Parameters.AddWithValue("@MakeandModel", (comboBox2.SelectedItem != null) ? comboBox2.SelectedItem : "");
                cmd.Parameters.AddWithValue("@SystemConfig", textBox2.Text.Trim());
                cmd.Parameters.AddWithValue("@Monitor", textBox8.Text.Trim());
                cmd.Parameters.AddWithValue("@Printer", (comboBox4.SelectedItem != null) ? comboBox4.SelectedItem : "");
                cmd.Parameters.AddWithValue("@OS", (comboBox5.SelectedItem != null) ? comboBox5.SelectedItem : "");
                cmd.Parameters.AddWithValue("@IPAddress", textBox3.Text.Trim());
                cmd.Parameters.AddWithValue("@AssetID", textBox4.Text.Trim());
                cmd.Parameters.AddWithValue("@Location", (comboBox7.SelectedItem != null) ? comboBox7.SelectedItem : "");
                cmd.Parameters.AddWithValue("@Department", (comboBox8.SelectedItem != null) ? comboBox8.SelectedItem : "");
                cmd.Parameters.AddWithValue("@Uname", textBox9.Text.Trim());
                cmd.Parameters.AddWithValue("@PrinterNumber", textBox6.Text.Trim());
                cmd.Parameters.AddWithValue("@Remarks", textBox7.Text.Trim());

                string sTypeEntry = "";
                foreach (string s in checkedListBox1.CheckedItems)
                {
                    if (s == "ADOBE")
                    {
                        sTypeEntry = sTypeEntry + s + "_" + textBox10.Text.Trim() + "_" + dateTimePicker4.Value.ToString("dd-MM-yyyy") + ",";
                    }
                    else
                    {
                        sTypeEntry = sTypeEntry + s + ",";
                    }
                }

                cmd.Parameters.AddWithValue("@SoftwareType", sTypeEntry);

                cmd.ExecuteNonQuery();
                con.Close();
                Clear();

                MessageBox.Show("Entry was successfully edited!");

                DataTable dt = this.hardwareEntryTableAdapter5.GetData();
                hardwareEntryDataGridView.DataSource = dt;
                textBox9.Text = "";
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (button5.Text.ToString() == "Edit Entries")
            {
                button4.Visible = false;
                button6.Visible = false;
                button7.Visible = false;
                button2.Visible = true;
                label1.Visible = true;
                comboBox6.Visible = true;
                button5.Text = "Exit Editing";
                label8.Visible = false;
                textBox10.Visible = false;
                label7.Visible = false;
                dateTimePicker4.Visible = false;
                groupBox1.Visible = false;
                textBox10.Text = "";
                Clear();

            }
            else if (button5.Text.ToString() == "Exit Editing")
            {
                button4.Visible = true;
                button6.Visible = true;
                button7.Visible = true;
                button2.Visible = false;
                button9.Visible = false;
                label1.Visible = false;
                comboBox6.Visible = false;
                comboBox6.Text = "";
                textBox9.Visible = false;
                button8.Visible = false;
                button1.Visible = false;
                label1.Text = "Search for :";
                button5.Text = "Edit Entries";
                label8.Visible = false;
                textBox10.Visible = false;
                label7.Visible = false;
                dateTimePicker4.Visible = false;
                groupBox1.Visible = false;
                textBox10.Text = "";

                DataTable dt = this.hardwareEntryTableAdapter5.GetData();
                hardwareEntryDataGridView.DataSource = dt;
                Clear();

            }
        }

        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox6.Visible = false;
            button9.Visible = true;
            textBox9.Visible = true;
            button8.Visible = true;
            button1.Visible = true;
            label1.Text = comboBox6.SelectedItem.ToString();
            textboxchange();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if(textBox9.Text != "")
            {
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                SqlDataAdapter sda = new SqlDataAdapter("select * from HardwareEntry where [" + label1.Text + "] = '" + textBox9.Text.Trim() + "'", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                try
                {
                    hardwareEntryDataGridView.DataSource = dt;
                    textBox5.Text = dt.Rows[0][0].ToString();
                    textBox1.Text = dt.Rows[0][1].ToString();
                    comboBox1.Text = dt.Rows[0][2].ToString();
                    comboBox2.Text = dt.Rows[0][3].ToString();
                    textBox2.Text = dt.Rows[0][4].ToString();
                    textBox8.Text = dt.Rows[0][5].ToString();
                    comboBox4.Text = dt.Rows[0][6].ToString();
                    comboBox5.Text = dt.Rows[0][7].ToString();
                    textBox3.Text = dt.Rows[0][8].ToString();
                    textBox4.Text = dt.Rows[0][9].ToString();
                    comboBox8.Text = dt.Rows[0][11].ToString();
                    comboBox7.Text = dt.Rows[0][12].ToString();
                    textBox7.Text = dt.Rows[0][13].ToString();
                    textBox6.Text = dt.Rows[0][14].ToString();

                    int i = 0;
                    while(!String.IsNullOrEmpty(dt.Rows[0][10].ToString().Split(',')[i]))
                    {
                        if (dt.Rows[0][10].ToString().Split(',')[i].Contains("ADOBE"))
                        {
                            checkedListBox1.SetItemChecked(1,true);
                            textBox10.Text = dt.Rows[0][10].ToString().Split(',')[i].ToString().Split('_')[1];
                            dateTimePicker4.Value = Convert.ToDateTime(dt.Rows[0][10].ToString().Split(',')[i].ToString().Split('_')[2]);
                            label8.Visible = true;
                            textBox10.Visible = true;
                            label7.Visible = true;
                            dateTimePicker4.Visible = true;
                            groupBox1.Visible = true;
                        }
                        else if(dt.Rows[0][10].ToString().Split(',')[i].Contains("OFFICE"))
                        {
                            checkedListBox1.SetItemChecked(0, true);
                        }
                        else if (dt.Rows[0][10].ToString().Split(',')[i].Contains("AUTO"))
                        {
                            checkedListBox1.SetItemChecked(2, true);
                        }
                        else if (dt.Rows[0][10].ToString().Split(',')[i].Contains("CORAL"))
                        {
                            checkedListBox1.SetItemChecked(3, true);
                        }
                        else if (dt.Rows[0][10].ToString().Split(',')[i].Contains("WINDOWS"))
                        {
                            checkedListBox1.SetItemChecked(4, true);
                        }
                        else if (dt.Rows[0][10].ToString().Split(',')[i].Contains("CAL"))
                        {
                            checkedListBox1.SetItemChecked(5, true);
                        }
                        else if (dt.Rows[0][10].ToString().Split(',')[i].Contains("WPS Office"))
                        {
                            checkedListBox1.SetItemChecked(5, true);
                        }
                        else if (dt.Rows[0][10].ToString().Split(',')[i].Contains("Solidworks Pro"))
                        {
                            checkedListBox1.SetItemChecked(5, true);
                        }
                        i++;
                    }
                    
                    con.Close();
                }
                catch(Exception ec)
                {
                    MessageBox.Show("No such Entry");
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            comboBox6.Text = "";
            comboBox6.Visible = true;
            textBox9.Visible = false;
            button8.Visible = false;
            button1.Visible = false;
            button9.Visible = false;
            label1.Text = "Search for :";
            label8.Visible = false;
            textBox10.Visible = false;
            label7.Visible = false;
            dateTimePicker4.Visible = false;
            groupBox1.Visible = false;
            textBox10.Text = "";
            Clear();

            DataTable dt = this.hardwareEntryTableAdapter5.GetData();
            hardwareEntryDataGridView.DataSource = dt;

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox5_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textboxchange();
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textboxchange();
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textboxchange();
            }
        }

        private void textBox3_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textboxchange();
            }
        }

        private void textBox4_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textboxchange();
            }
        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            textboxchange();
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            textboxchange();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textboxchange();
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            textboxchange();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            textboxchange();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Entries ss = new Entries("Hardware");
            ss.ShowDialog();
            ss.Dispose();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Select ss = new Select();
            this.Hide();
            ss.ShowDialog();
        }


        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textboxchange();

            bool isAdobe = false;

            foreach(string s in checkedListBox1.CheckedItems)
            {
                if(s == "ADOBE")
                {
                    isAdobe = true;
                }
            }

            if (isAdobe)
            {
                label8.Visible = true;
                textBox10.Visible = true;
                label7.Visible = true;
                dateTimePicker4.Visible = true;
                groupBox1.Visible = true;
            }
            else
            {
                label8.Visible = false;
                textBox10.Visible = false;
                label7.Visible = false;
                dateTimePicker4.Visible = false;
                groupBox1.Visible = false;
                textBox10.Text = "";
            }
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Are you sure you want do delete entries with " + label1.Text + ": " + textBox9.Text.Trim() + "?", "Message", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("delete from HardwareEntry where [" + label1.Text + "]='" + textBox9.Text.Trim() + "'", con);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Entry Successfully deleted!");
                    con.Close();
                    DataTable dt = this.hardwareEntryTableAdapter5.GetData();
                    hardwareEntryDataGridView.DataSource = dt;
                }
                catch (Exception ec)
                {
                    MessageBox.Show(ec.Message);
                    con.Close();
                }
                Clear();
            }
            
        }

        private void comboBox8_SelectedIndexChanged(object sender, EventArgs e)
        {
            textboxchange();
        }

        private void comboBox7_SelectedIndexChanged(object sender, EventArgs e)
        {
            textboxchange();
        }

        private void HardwareEntry_Resize(object sender, EventArgs e)
        {
        }
    }
}
