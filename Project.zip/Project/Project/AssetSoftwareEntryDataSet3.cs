﻿namespace Assets_Software_Entry
{


    partial class AssetSoftwareEntryDataSet3
    {
    }
}

namespace Assets_Software_Entry.AssetSoftwareEntryDataSet3TableAdapters {
    
    
    public partial class AssetSoftwareEntryTableAdapter {
    }
}
