﻿using System.Net;
using System.Net.Mail;
using System.Security.Cryptography.X509Certificates;

namespace Assets_Software_Entry
{
    internal class EmailRegister
    {
        SmtpClient smtpClient;
        static string fromEmail = "cktinfotech920@gmail.com";
        static string password = "dpduhvk1";
        public EmailRegister()
        {
            smtpClient = new SmtpClient()
            {
                Host = "smtp.gmail.com",
                Port = 587,
                EnableSsl = true,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential(fromEmail, password)
            };
        }

        public void Send(string toAddr)
        {
            using (var m = new MailMessage(fromEmail, toAddr)
            {
                Subject = "Registration Successful",
                Body = "Congratulations! Your Registration was successful.",
            })
            {
                m.IsBodyHtml = true;
                smtpClient.Send(m);
            }
        }
    }
}