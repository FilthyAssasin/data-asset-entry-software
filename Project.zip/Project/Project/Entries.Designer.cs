﻿namespace Assets_Software_Entry
{
    partial class Entries
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Entries));
            this.button7 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.assetSoftwareEntryDataGridView = new System.Windows.Forms.DataGridView();
            this.srNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.companyNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.softwareTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.assetsDescriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supplierDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.authorizationNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.assetNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.poNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.softwareAssuranceDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.licenseTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.poDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.remarksDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.licenseNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.licenseDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.assetSoftwareEntryBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.finalDSBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.finalDS = new Assets_Software_Entry.FinalDS();
            this.assetSoftwareEntryBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.softEntryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.softEntry = new Assets_Software_Entry.softEntry();
            this.assetSoftwareEntryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.entriesSetBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.entriesSet = new Assets_Software_Entry.EntriesSet();
            this.assetSoftwareEntryBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.assetSoftwareEntryDataSet3BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.assetSoftwareEntryDataSet3 = new Assets_Software_Entry.AssetSoftwareEntryDataSet3();
            this.button4 = new System.Windows.Forms.Button();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.assetSoftwareEntryBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.assetSoftwareEntryBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.assetSoftwareEntryTableAdapter2 = new Assets_Software_Entry.AssetSoftwareEntryDataSet3TableAdapters.AssetSoftwareEntryTableAdapter();
            this.hardwareEntryDataGridView = new System.Windows.Forms.DataGridView();
            this.companyNameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pCTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.makeAndModelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.systemConfigDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.monitorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.printerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oSDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iPAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.assetIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.softwareTypeDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.departmentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.locationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.remarksDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.printerNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hardwareEntryBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.finalDSBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.hardwareEntryBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.entriesSetBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.hardwareEntryBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.hEntryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.hEntry = new Assets_Software_Entry.HEntry();
            this.hardwareEntryBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.hardwareEntryfinishBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.hardwareEntryfinish = new Assets_Software_Entry.hardwareEntryfinish();
            this.hardwareEntryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.hardwareDataSetFinal = new Assets_Software_Entry.hardwareDataSetFinal();
            this.hardwareEntryTableAdapter = new Assets_Software_Entry.hardwareDataSetFinalTableAdapters.HardwareEntryTableAdapter();
            this.domainDataGridView = new System.Windows.Forms.DataGridView();
            this.companyNameDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.registrantNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.creationDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.expiryDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.renewalDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bookedWithDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.domainUsedDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.remarksDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.domainBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.finalDSBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.domainBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.entriesSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.domainBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.domainDataSet = new Assets_Software_Entry.DomainDataSet();
            this.domainTableAdapter = new Assets_Software_Entry.DomainDataSetTableAdapters.DomainTableAdapter();
            this.hardwareEntryBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.hardwareEntryTableAdapter1 = new Assets_Software_Entry.hardwareEntryfinishTableAdapters.HardwareEntryTableAdapter();
            this.hardwareEntryTableAdapter2 = new Assets_Software_Entry.HEntryTableAdapters.HardwareEntryTableAdapter();
            this.domainTableAdapter1 = new Assets_Software_Entry.EntriesSetTableAdapters.DomainTableAdapter();
            this.hardwareEntryTableAdapter3 = new Assets_Software_Entry.EntriesSetTableAdapters.HardwareEntryTableAdapter();
            this.assetSoftwareEntryTableAdapter = new Assets_Software_Entry.EntriesSetTableAdapters.AssetSoftwareEntryTableAdapter();
            this.assetSoftwareEntryTableAdapter1 = new Assets_Software_Entry.softEntryTableAdapters.AssetSoftwareEntryTableAdapter();
            this.label20 = new System.Windows.Forms.Label();
            this.hardwareEntryTableAdapter4 = new Assets_Software_Entry.FinalDSTableAdapters.HardwareEntryTableAdapter();
            this.domainTableAdapter2 = new Assets_Software_Entry.FinalDSTableAdapters.DomainTableAdapter();
            this.assetSoftwareEntryTableAdapter3 = new Assets_Software_Entry.FinalDSTableAdapters.AssetSoftwareEntryTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryBindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalDSBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalDS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.softEntryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.softEntry)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.entriesSetBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.entriesSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryDataSet3BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryDataSet3)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareEntryDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareEntryBindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalDSBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareEntryBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.entriesSetBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareEntryBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hEntryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hEntry)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareEntryBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareEntryfinishBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareEntryfinish)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareEntryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareDataSetFinal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalDSBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.entriesSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareEntryBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // button7
            // 
            this.button7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button7.BackgroundImage")));
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button7.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Image = ((System.Drawing.Image)(resources.GetObject("button7.Image")));
            this.button7.Location = new System.Drawing.Point(0, 1);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(64, 52);
            this.button7.TabIndex = 36;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button2.BackgroundImage")));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(926, 75);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(105, 36);
            this.button2.TabIndex = 38;
            this.button2.Text = "Search";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox5
            // 
            this.textBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(670, 82);
            this.textBox5.MaximumSize = new System.Drawing.Size(250, 30);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(250, 22);
            this.textBox5.TabIndex = 39;
            this.textBox5.Visible = false;
            // 
            // assetSoftwareEntryDataGridView
            // 
            this.assetSoftwareEntryDataGridView.AllowUserToAddRows = false;
            this.assetSoftwareEntryDataGridView.AllowUserToDeleteRows = false;
            this.assetSoftwareEntryDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.assetSoftwareEntryDataGridView.AutoGenerateColumns = false;
            this.assetSoftwareEntryDataGridView.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.assetSoftwareEntryDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.assetSoftwareEntryDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.srNoDataGridViewTextBoxColumn,
            this.companyNameDataGridViewTextBoxColumn,
            this.softwareTypeDataGridViewTextBoxColumn,
            this.assetsDescriptionDataGridViewTextBoxColumn,
            this.qtyDataGridViewTextBoxColumn,
            this.supplierDataGridViewTextBoxColumn,
            this.authorizationNumberDataGridViewTextBoxColumn,
            this.assetNumberDataGridViewTextBoxColumn,
            this.poNumberDataGridViewTextBoxColumn,
            this.invNumberDataGridViewTextBoxColumn,
            this.softwareAssuranceDateDataGridViewTextBoxColumn,
            this.licenseTypeDataGridViewTextBoxColumn,
            this.poDateDataGridViewTextBoxColumn,
            this.invDateDataGridViewTextBoxColumn,
            this.remarksDataGridViewTextBoxColumn2,
            this.licenseNumberDataGridViewTextBoxColumn,
            this.licenseDateDataGridViewTextBoxColumn});
            this.assetSoftwareEntryDataGridView.DataSource = this.assetSoftwareEntryBindingSource5;
            this.assetSoftwareEntryDataGridView.Location = new System.Drawing.Point(0, 117);
            this.assetSoftwareEntryDataGridView.Name = "assetSoftwareEntryDataGridView";
            this.assetSoftwareEntryDataGridView.ReadOnly = true;
            this.assetSoftwareEntryDataGridView.Size = new System.Drawing.Size(1311, 411);
            this.assetSoftwareEntryDataGridView.TabIndex = 41;
            this.assetSoftwareEntryDataGridView.Visible = false;
            // 
            // srNoDataGridViewTextBoxColumn
            // 
            this.srNoDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.srNoDataGridViewTextBoxColumn.DataPropertyName = "Sr_ No_";
            this.srNoDataGridViewTextBoxColumn.HeaderText = "Sr_ No_";
            this.srNoDataGridViewTextBoxColumn.Name = "srNoDataGridViewTextBoxColumn";
            this.srNoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // companyNameDataGridViewTextBoxColumn
            // 
            this.companyNameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.companyNameDataGridViewTextBoxColumn.DataPropertyName = "Company Name";
            this.companyNameDataGridViewTextBoxColumn.HeaderText = "Company Name";
            this.companyNameDataGridViewTextBoxColumn.Name = "companyNameDataGridViewTextBoxColumn";
            this.companyNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // softwareTypeDataGridViewTextBoxColumn
            // 
            this.softwareTypeDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.softwareTypeDataGridViewTextBoxColumn.DataPropertyName = "Software Type";
            this.softwareTypeDataGridViewTextBoxColumn.HeaderText = "Software Type";
            this.softwareTypeDataGridViewTextBoxColumn.Name = "softwareTypeDataGridViewTextBoxColumn";
            this.softwareTypeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // assetsDescriptionDataGridViewTextBoxColumn
            // 
            this.assetsDescriptionDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.assetsDescriptionDataGridViewTextBoxColumn.DataPropertyName = "Assets Description";
            this.assetsDescriptionDataGridViewTextBoxColumn.HeaderText = "Product Description";
            this.assetsDescriptionDataGridViewTextBoxColumn.Name = "assetsDescriptionDataGridViewTextBoxColumn";
            this.assetsDescriptionDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // qtyDataGridViewTextBoxColumn
            // 
            this.qtyDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.qtyDataGridViewTextBoxColumn.DataPropertyName = "Qty";
            this.qtyDataGridViewTextBoxColumn.HeaderText = "Qty";
            this.qtyDataGridViewTextBoxColumn.Name = "qtyDataGridViewTextBoxColumn";
            this.qtyDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // supplierDataGridViewTextBoxColumn
            // 
            this.supplierDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.supplierDataGridViewTextBoxColumn.DataPropertyName = "Supplier";
            this.supplierDataGridViewTextBoxColumn.HeaderText = "Supplier";
            this.supplierDataGridViewTextBoxColumn.Name = "supplierDataGridViewTextBoxColumn";
            this.supplierDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // authorizationNumberDataGridViewTextBoxColumn
            // 
            this.authorizationNumberDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.authorizationNumberDataGridViewTextBoxColumn.DataPropertyName = "Authorization Number";
            this.authorizationNumberDataGridViewTextBoxColumn.HeaderText = "Authorization Number";
            this.authorizationNumberDataGridViewTextBoxColumn.Name = "authorizationNumberDataGridViewTextBoxColumn";
            this.authorizationNumberDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // assetNumberDataGridViewTextBoxColumn
            // 
            this.assetNumberDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.assetNumberDataGridViewTextBoxColumn.DataPropertyName = "Asset Number";
            this.assetNumberDataGridViewTextBoxColumn.HeaderText = "Part Number";
            this.assetNumberDataGridViewTextBoxColumn.Name = "assetNumberDataGridViewTextBoxColumn";
            this.assetNumberDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // poNumberDataGridViewTextBoxColumn
            // 
            this.poNumberDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.poNumberDataGridViewTextBoxColumn.DataPropertyName = "Po Number";
            this.poNumberDataGridViewTextBoxColumn.HeaderText = "Po Number";
            this.poNumberDataGridViewTextBoxColumn.Name = "poNumberDataGridViewTextBoxColumn";
            this.poNumberDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // invNumberDataGridViewTextBoxColumn
            // 
            this.invNumberDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.invNumberDataGridViewTextBoxColumn.DataPropertyName = "Inv Number";
            this.invNumberDataGridViewTextBoxColumn.HeaderText = "Vendor Inv Number";
            this.invNumberDataGridViewTextBoxColumn.Name = "invNumberDataGridViewTextBoxColumn";
            this.invNumberDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // softwareAssuranceDateDataGridViewTextBoxColumn
            // 
            this.softwareAssuranceDateDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.softwareAssuranceDateDataGridViewTextBoxColumn.DataPropertyName = "Software Assurance Date";
            this.softwareAssuranceDateDataGridViewTextBoxColumn.HeaderText = "Software Assurance Date";
            this.softwareAssuranceDateDataGridViewTextBoxColumn.Name = "softwareAssuranceDateDataGridViewTextBoxColumn";
            this.softwareAssuranceDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // licenseTypeDataGridViewTextBoxColumn
            // 
            this.licenseTypeDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.licenseTypeDataGridViewTextBoxColumn.DataPropertyName = "License Type";
            this.licenseTypeDataGridViewTextBoxColumn.HeaderText = "License Type";
            this.licenseTypeDataGridViewTextBoxColumn.Name = "licenseTypeDataGridViewTextBoxColumn";
            this.licenseTypeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // poDateDataGridViewTextBoxColumn
            // 
            this.poDateDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.poDateDataGridViewTextBoxColumn.DataPropertyName = "Po Date";
            this.poDateDataGridViewTextBoxColumn.HeaderText = "Po Date";
            this.poDateDataGridViewTextBoxColumn.Name = "poDateDataGridViewTextBoxColumn";
            this.poDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // invDateDataGridViewTextBoxColumn
            // 
            this.invDateDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.invDateDataGridViewTextBoxColumn.DataPropertyName = "Inv Date";
            this.invDateDataGridViewTextBoxColumn.HeaderText = "Inv Date";
            this.invDateDataGridViewTextBoxColumn.Name = "invDateDataGridViewTextBoxColumn";
            this.invDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // remarksDataGridViewTextBoxColumn2
            // 
            this.remarksDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.remarksDataGridViewTextBoxColumn2.DataPropertyName = "Remarks";
            this.remarksDataGridViewTextBoxColumn2.HeaderText = "Remarks";
            this.remarksDataGridViewTextBoxColumn2.Name = "remarksDataGridViewTextBoxColumn2";
            this.remarksDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // licenseNumberDataGridViewTextBoxColumn
            // 
            this.licenseNumberDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.licenseNumberDataGridViewTextBoxColumn.DataPropertyName = "License Number";
            this.licenseNumberDataGridViewTextBoxColumn.HeaderText = "License Number";
            this.licenseNumberDataGridViewTextBoxColumn.Name = "licenseNumberDataGridViewTextBoxColumn";
            this.licenseNumberDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // licenseDateDataGridViewTextBoxColumn
            // 
            this.licenseDateDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.licenseDateDataGridViewTextBoxColumn.DataPropertyName = "License Date";
            this.licenseDateDataGridViewTextBoxColumn.HeaderText = "License Date";
            this.licenseDateDataGridViewTextBoxColumn.Name = "licenseDateDataGridViewTextBoxColumn";
            this.licenseDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // assetSoftwareEntryBindingSource5
            // 
            this.assetSoftwareEntryBindingSource5.DataMember = "AssetSoftwareEntry";
            this.assetSoftwareEntryBindingSource5.DataSource = this.finalDSBindingSource2;
            // 
            // finalDSBindingSource2
            // 
            this.finalDSBindingSource2.DataSource = this.finalDS;
            this.finalDSBindingSource2.Position = 0;
            // 
            // finalDS
            // 
            this.finalDS.DataSetName = "FinalDS";
            this.finalDS.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // assetSoftwareEntryBindingSource1
            // 
            this.assetSoftwareEntryBindingSource1.DataMember = "AssetSoftwareEntry";
            this.assetSoftwareEntryBindingSource1.DataSource = this.softEntryBindingSource;
            // 
            // softEntryBindingSource
            // 
            this.softEntryBindingSource.DataSource = this.softEntry;
            this.softEntryBindingSource.Position = 0;
            // 
            // softEntry
            // 
            this.softEntry.DataSetName = "softEntry";
            this.softEntry.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // assetSoftwareEntryBindingSource
            // 
            this.assetSoftwareEntryBindingSource.DataMember = "AssetSoftwareEntry";
            this.assetSoftwareEntryBindingSource.DataSource = this.entriesSetBindingSource2;
            // 
            // entriesSetBindingSource2
            // 
            this.entriesSetBindingSource2.DataSource = this.entriesSet;
            this.entriesSetBindingSource2.Position = 0;
            // 
            // entriesSet
            // 
            this.entriesSet.DataSetName = "EntriesSet";
            this.entriesSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // assetSoftwareEntryBindingSource4
            // 
            this.assetSoftwareEntryBindingSource4.DataMember = "AssetSoftwareEntry";
            this.assetSoftwareEntryBindingSource4.DataSource = this.assetSoftwareEntryDataSet3BindingSource;
            // 
            // assetSoftwareEntryDataSet3BindingSource
            // 
            this.assetSoftwareEntryDataSet3BindingSource.DataSource = this.assetSoftwareEntryDataSet3;
            this.assetSoftwareEntryDataSet3BindingSource.Position = 0;
            // 
            // assetSoftwareEntryDataSet3
            // 
            this.assetSoftwareEntryDataSet3.DataSetName = "AssetSoftwareEntryDataSet3";
            this.assetSoftwareEntryDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button4
            // 
            this.button4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button4.BackgroundImage")));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button4.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(1037, 74);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(128, 36);
            this.button4.TabIndex = 42;
            this.button4.Text = "Delete Entry";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Visible = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // printDialog1
            // 
            this.printDialog1.UseEXDialog = true;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(666, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 23);
            this.label2.TabIndex = 43;
            this.label2.Text = "Search for :";
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Sr. No.",
            "Company Name",
            "Authorization Number",
            "Part Number"});
            this.comboBox1.Location = new System.Drawing.Point(670, 82);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(250, 21);
            this.comboBox1.TabIndex = 44;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(1171, 72);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(128, 36);
            this.button1.TabIndex = 45;
            this.button1.Text = "Reset";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.textBox5);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Location = new System.Drawing.Point(0, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1311, 116);
            this.panel1.TabIndex = 46;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // button3
            // 
            this.button3.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.button3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button3.BackgroundImage")));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(1030, 534);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(125, 55);
            this.button3.TabIndex = 46;
            this.button3.Text = "Export To Excel";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // button5
            // 
            this.button5.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.button5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button5.BackgroundImage")));
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button5.Font = new System.Drawing.Font("Century", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(892, 534);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(132, 54);
            this.button5.TabIndex = 47;
            this.button5.Text = "Print";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // assetSoftwareEntryBindingSource2
            // 
            this.assetSoftwareEntryBindingSource2.DataMember = "AssetSoftwareEntry";
            this.assetSoftwareEntryBindingSource2.DataSource = this.assetSoftwareEntryDataSet3;
            // 
            // assetSoftwareEntryBindingSource3
            // 
            this.assetSoftwareEntryBindingSource3.DataMember = "AssetSoftwareEntry";
            this.assetSoftwareEntryBindingSource3.DataSource = this.assetSoftwareEntryDataSet3BindingSource;
            // 
            // assetSoftwareEntryTableAdapter2
            // 
            this.assetSoftwareEntryTableAdapter2.ClearBeforeFill = true;
            // 
            // hardwareEntryDataGridView
            // 
            this.hardwareEntryDataGridView.AllowUserToAddRows = false;
            this.hardwareEntryDataGridView.AllowUserToDeleteRows = false;
            this.hardwareEntryDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.hardwareEntryDataGridView.AutoGenerateColumns = false;
            this.hardwareEntryDataGridView.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.hardwareEntryDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.hardwareEntryDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.companyNameDataGridViewTextBoxColumn1,
            this.usernameDataGridViewTextBoxColumn,
            this.pCTypeDataGridViewTextBoxColumn,
            this.makeAndModelDataGridViewTextBoxColumn,
            this.systemConfigDataGridViewTextBoxColumn,
            this.monitorDataGridViewTextBoxColumn,
            this.printerDataGridViewTextBoxColumn,
            this.oSDataGridViewTextBoxColumn,
            this.iPAddressDataGridViewTextBoxColumn,
            this.assetIDDataGridViewTextBoxColumn,
            this.softwareTypeDataGridViewTextBoxColumn1,
            this.departmentDataGridViewTextBoxColumn,
            this.locationDataGridViewTextBoxColumn,
            this.remarksDataGridViewTextBoxColumn1,
            this.printerNumberDataGridViewTextBoxColumn});
            this.hardwareEntryDataGridView.DataSource = this.hardwareEntryBindingSource5;
            this.hardwareEntryDataGridView.Location = new System.Drawing.Point(0, 117);
            this.hardwareEntryDataGridView.Name = "hardwareEntryDataGridView";
            this.hardwareEntryDataGridView.ReadOnly = true;
            this.hardwareEntryDataGridView.Size = new System.Drawing.Size(1311, 411);
            this.hardwareEntryDataGridView.TabIndex = 62;
            this.hardwareEntryDataGridView.Visible = false;
            // 
            // companyNameDataGridViewTextBoxColumn1
            // 
            this.companyNameDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.companyNameDataGridViewTextBoxColumn1.DataPropertyName = "Company Name";
            this.companyNameDataGridViewTextBoxColumn1.HeaderText = "Company Name";
            this.companyNameDataGridViewTextBoxColumn1.Name = "companyNameDataGridViewTextBoxColumn1";
            this.companyNameDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // usernameDataGridViewTextBoxColumn
            // 
            this.usernameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.usernameDataGridViewTextBoxColumn.DataPropertyName = "Username";
            this.usernameDataGridViewTextBoxColumn.HeaderText = "Username";
            this.usernameDataGridViewTextBoxColumn.Name = "usernameDataGridViewTextBoxColumn";
            this.usernameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pCTypeDataGridViewTextBoxColumn
            // 
            this.pCTypeDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.pCTypeDataGridViewTextBoxColumn.DataPropertyName = "PC Type";
            this.pCTypeDataGridViewTextBoxColumn.HeaderText = "PC Type";
            this.pCTypeDataGridViewTextBoxColumn.Name = "pCTypeDataGridViewTextBoxColumn";
            this.pCTypeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // makeAndModelDataGridViewTextBoxColumn
            // 
            this.makeAndModelDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.makeAndModelDataGridViewTextBoxColumn.DataPropertyName = "Make and Model";
            this.makeAndModelDataGridViewTextBoxColumn.HeaderText = "Make and Model";
            this.makeAndModelDataGridViewTextBoxColumn.Name = "makeAndModelDataGridViewTextBoxColumn";
            this.makeAndModelDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // systemConfigDataGridViewTextBoxColumn
            // 
            this.systemConfigDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.systemConfigDataGridViewTextBoxColumn.DataPropertyName = "System Config";
            this.systemConfigDataGridViewTextBoxColumn.HeaderText = "System Config";
            this.systemConfigDataGridViewTextBoxColumn.Name = "systemConfigDataGridViewTextBoxColumn";
            this.systemConfigDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // monitorDataGridViewTextBoxColumn
            // 
            this.monitorDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.monitorDataGridViewTextBoxColumn.DataPropertyName = "Monitor";
            this.monitorDataGridViewTextBoxColumn.HeaderText = "Monitor";
            this.monitorDataGridViewTextBoxColumn.Name = "monitorDataGridViewTextBoxColumn";
            this.monitorDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // printerDataGridViewTextBoxColumn
            // 
            this.printerDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.printerDataGridViewTextBoxColumn.DataPropertyName = "Printer";
            this.printerDataGridViewTextBoxColumn.HeaderText = "Printer";
            this.printerDataGridViewTextBoxColumn.Name = "printerDataGridViewTextBoxColumn";
            this.printerDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // oSDataGridViewTextBoxColumn
            // 
            this.oSDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.oSDataGridViewTextBoxColumn.DataPropertyName = "O/S";
            this.oSDataGridViewTextBoxColumn.HeaderText = "O/S";
            this.oSDataGridViewTextBoxColumn.Name = "oSDataGridViewTextBoxColumn";
            this.oSDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // iPAddressDataGridViewTextBoxColumn
            // 
            this.iPAddressDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.iPAddressDataGridViewTextBoxColumn.DataPropertyName = "IP Address";
            this.iPAddressDataGridViewTextBoxColumn.HeaderText = "IP Address";
            this.iPAddressDataGridViewTextBoxColumn.Name = "iPAddressDataGridViewTextBoxColumn";
            this.iPAddressDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // assetIDDataGridViewTextBoxColumn
            // 
            this.assetIDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.assetIDDataGridViewTextBoxColumn.DataPropertyName = "Asset ID";
            this.assetIDDataGridViewTextBoxColumn.HeaderText = "Asset ID";
            this.assetIDDataGridViewTextBoxColumn.Name = "assetIDDataGridViewTextBoxColumn";
            this.assetIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // softwareTypeDataGridViewTextBoxColumn1
            // 
            this.softwareTypeDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.softwareTypeDataGridViewTextBoxColumn1.DataPropertyName = "Software Type";
            this.softwareTypeDataGridViewTextBoxColumn1.HeaderText = "Software Type";
            this.softwareTypeDataGridViewTextBoxColumn1.Name = "softwareTypeDataGridViewTextBoxColumn1";
            this.softwareTypeDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // departmentDataGridViewTextBoxColumn
            // 
            this.departmentDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.departmentDataGridViewTextBoxColumn.DataPropertyName = "Department";
            this.departmentDataGridViewTextBoxColumn.HeaderText = "Department";
            this.departmentDataGridViewTextBoxColumn.Name = "departmentDataGridViewTextBoxColumn";
            this.departmentDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // locationDataGridViewTextBoxColumn
            // 
            this.locationDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.locationDataGridViewTextBoxColumn.DataPropertyName = "Location";
            this.locationDataGridViewTextBoxColumn.HeaderText = "Location";
            this.locationDataGridViewTextBoxColumn.Name = "locationDataGridViewTextBoxColumn";
            this.locationDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // remarksDataGridViewTextBoxColumn1
            // 
            this.remarksDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.remarksDataGridViewTextBoxColumn1.DataPropertyName = "Remarks";
            this.remarksDataGridViewTextBoxColumn1.HeaderText = "Remarks";
            this.remarksDataGridViewTextBoxColumn1.Name = "remarksDataGridViewTextBoxColumn1";
            this.remarksDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // printerNumberDataGridViewTextBoxColumn
            // 
            this.printerNumberDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.printerNumberDataGridViewTextBoxColumn.DataPropertyName = "Printer Number";
            this.printerNumberDataGridViewTextBoxColumn.HeaderText = "Printer Number";
            this.printerNumberDataGridViewTextBoxColumn.Name = "printerNumberDataGridViewTextBoxColumn";
            this.printerNumberDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // hardwareEntryBindingSource5
            // 
            this.hardwareEntryBindingSource5.DataMember = "HardwareEntry";
            this.hardwareEntryBindingSource5.DataSource = this.finalDSBindingSource;
            // 
            // finalDSBindingSource
            // 
            this.finalDSBindingSource.DataSource = this.finalDS;
            this.finalDSBindingSource.Position = 0;
            // 
            // hardwareEntryBindingSource4
            // 
            this.hardwareEntryBindingSource4.DataMember = "HardwareEntry";
            this.hardwareEntryBindingSource4.DataSource = this.entriesSetBindingSource1;
            // 
            // entriesSetBindingSource1
            // 
            this.entriesSetBindingSource1.DataSource = this.entriesSet;
            this.entriesSetBindingSource1.Position = 0;
            // 
            // hardwareEntryBindingSource3
            // 
            this.hardwareEntryBindingSource3.DataMember = "HardwareEntry";
            this.hardwareEntryBindingSource3.DataSource = this.hEntryBindingSource;
            // 
            // hEntryBindingSource
            // 
            this.hEntryBindingSource.DataSource = this.hEntry;
            this.hEntryBindingSource.Position = 0;
            // 
            // hEntry
            // 
            this.hEntry.DataSetName = "HEntry";
            this.hEntry.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // hardwareEntryBindingSource2
            // 
            this.hardwareEntryBindingSource2.DataMember = "HardwareEntry";
            this.hardwareEntryBindingSource2.DataSource = this.hardwareEntryfinishBindingSource;
            // 
            // hardwareEntryfinishBindingSource
            // 
            this.hardwareEntryfinishBindingSource.DataSource = this.hardwareEntryfinish;
            this.hardwareEntryfinishBindingSource.Position = 0;
            // 
            // hardwareEntryfinish
            // 
            this.hardwareEntryfinish.DataSetName = "hardwareEntryfinish";
            this.hardwareEntryfinish.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // hardwareEntryBindingSource
            // 
            this.hardwareEntryBindingSource.DataMember = "HardwareEntry";
            this.hardwareEntryBindingSource.DataSource = this.hardwareDataSetFinal;
            // 
            // hardwareDataSetFinal
            // 
            this.hardwareDataSetFinal.DataSetName = "hardwareDataSetFinal";
            this.hardwareDataSetFinal.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // hardwareEntryTableAdapter
            // 
            this.hardwareEntryTableAdapter.ClearBeforeFill = true;
            // 
            // domainDataGridView
            // 
            this.domainDataGridView.AllowUserToAddRows = false;
            this.domainDataGridView.AllowUserToDeleteRows = false;
            this.domainDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.domainDataGridView.AutoGenerateColumns = false;
            this.domainDataGridView.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.domainDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.domainDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.companyNameDataGridViewTextBoxColumn2,
            this.nameDataGridViewTextBoxColumn,
            this.registrantNameDataGridViewTextBoxColumn,
            this.creationDateDataGridViewTextBoxColumn,
            this.expiryDateDataGridViewTextBoxColumn,
            this.renewalDateDataGridViewTextBoxColumn,
            this.bookedWithDataGridViewTextBoxColumn,
            this.domainUsedDataGridViewTextBoxColumn,
            this.remarksDataGridViewTextBoxColumn});
            this.domainDataGridView.DataSource = this.domainBindingSource2;
            this.domainDataGridView.Location = new System.Drawing.Point(0, 117);
            this.domainDataGridView.Name = "domainDataGridView";
            this.domainDataGridView.ReadOnly = true;
            this.domainDataGridView.Size = new System.Drawing.Size(1311, 411);
            this.domainDataGridView.TabIndex = 74;
            this.domainDataGridView.Visible = false;
            // 
            // companyNameDataGridViewTextBoxColumn2
            // 
            this.companyNameDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.companyNameDataGridViewTextBoxColumn2.DataPropertyName = "Company Name";
            this.companyNameDataGridViewTextBoxColumn2.HeaderText = "Company Name";
            this.companyNameDataGridViewTextBoxColumn2.Name = "companyNameDataGridViewTextBoxColumn2";
            this.companyNameDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // registrantNameDataGridViewTextBoxColumn
            // 
            this.registrantNameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.registrantNameDataGridViewTextBoxColumn.DataPropertyName = "Registrant Name";
            this.registrantNameDataGridViewTextBoxColumn.HeaderText = "Registrant Name";
            this.registrantNameDataGridViewTextBoxColumn.Name = "registrantNameDataGridViewTextBoxColumn";
            this.registrantNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // creationDateDataGridViewTextBoxColumn
            // 
            this.creationDateDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.creationDateDataGridViewTextBoxColumn.DataPropertyName = "Creation Date";
            this.creationDateDataGridViewTextBoxColumn.HeaderText = "Creation Date";
            this.creationDateDataGridViewTextBoxColumn.Name = "creationDateDataGridViewTextBoxColumn";
            this.creationDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // expiryDateDataGridViewTextBoxColumn
            // 
            this.expiryDateDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.expiryDateDataGridViewTextBoxColumn.DataPropertyName = "Expiry Date";
            this.expiryDateDataGridViewTextBoxColumn.HeaderText = "Expiry Date";
            this.expiryDateDataGridViewTextBoxColumn.Name = "expiryDateDataGridViewTextBoxColumn";
            this.expiryDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // renewalDateDataGridViewTextBoxColumn
            // 
            this.renewalDateDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.renewalDateDataGridViewTextBoxColumn.DataPropertyName = "Renewal Date";
            this.renewalDateDataGridViewTextBoxColumn.HeaderText = "Renewal Date";
            this.renewalDateDataGridViewTextBoxColumn.Name = "renewalDateDataGridViewTextBoxColumn";
            this.renewalDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // bookedWithDataGridViewTextBoxColumn
            // 
            this.bookedWithDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.bookedWithDataGridViewTextBoxColumn.DataPropertyName = "Booked With";
            this.bookedWithDataGridViewTextBoxColumn.HeaderText = "Booked With";
            this.bookedWithDataGridViewTextBoxColumn.Name = "bookedWithDataGridViewTextBoxColumn";
            this.bookedWithDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // domainUsedDataGridViewTextBoxColumn
            // 
            this.domainUsedDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.domainUsedDataGridViewTextBoxColumn.DataPropertyName = "Domain Used";
            this.domainUsedDataGridViewTextBoxColumn.HeaderText = "Domain Used";
            this.domainUsedDataGridViewTextBoxColumn.Name = "domainUsedDataGridViewTextBoxColumn";
            this.domainUsedDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // remarksDataGridViewTextBoxColumn
            // 
            this.remarksDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.remarksDataGridViewTextBoxColumn.DataPropertyName = "Remarks";
            this.remarksDataGridViewTextBoxColumn.HeaderText = "Remarks";
            this.remarksDataGridViewTextBoxColumn.Name = "remarksDataGridViewTextBoxColumn";
            this.remarksDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // domainBindingSource2
            // 
            this.domainBindingSource2.DataMember = "Domain";
            this.domainBindingSource2.DataSource = this.finalDSBindingSource1;
            // 
            // finalDSBindingSource1
            // 
            this.finalDSBindingSource1.DataSource = this.finalDS;
            this.finalDSBindingSource1.Position = 0;
            // 
            // domainBindingSource1
            // 
            this.domainBindingSource1.DataMember = "Domain";
            this.domainBindingSource1.DataSource = this.entriesSetBindingSource;
            // 
            // entriesSetBindingSource
            // 
            this.entriesSetBindingSource.DataSource = this.entriesSet;
            this.entriesSetBindingSource.Position = 0;
            // 
            // domainBindingSource
            // 
            this.domainBindingSource.DataMember = "Domain";
            this.domainBindingSource.DataSource = this.domainDataSet;
            // 
            // domainDataSet
            // 
            this.domainDataSet.DataSetName = "DomainDataSet";
            this.domainDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // domainTableAdapter
            // 
            this.domainTableAdapter.ClearBeforeFill = true;
            // 
            // hardwareEntryBindingSource1
            // 
            this.hardwareEntryBindingSource1.DataMember = "HardwareEntry";
            this.hardwareEntryBindingSource1.DataSource = this.hardwareEntryfinish;
            // 
            // hardwareEntryTableAdapter1
            // 
            this.hardwareEntryTableAdapter1.ClearBeforeFill = true;
            // 
            // hardwareEntryTableAdapter2
            // 
            this.hardwareEntryTableAdapter2.ClearBeforeFill = true;
            // 
            // domainTableAdapter1
            // 
            this.domainTableAdapter1.ClearBeforeFill = true;
            // 
            // hardwareEntryTableAdapter3
            // 
            this.hardwareEntryTableAdapter3.ClearBeforeFill = true;
            // 
            // assetSoftwareEntryTableAdapter
            // 
            this.assetSoftwareEntryTableAdapter.ClearBeforeFill = true;
            // 
            // assetSoftwareEntryTableAdapter1
            // 
            this.assetSoftwareEntryTableAdapter1.ClearBeforeFill = true;
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label20.Location = new System.Drawing.Point(12, 571);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(202, 18);
            this.label20.TabIndex = 78;
            this.label20.Text = "Developed by CKT Infotech";
            // 
            // hardwareEntryTableAdapter4
            // 
            this.hardwareEntryTableAdapter4.ClearBeforeFill = true;
            // 
            // domainTableAdapter2
            // 
            this.domainTableAdapter2.ClearBeforeFill = true;
            // 
            // assetSoftwareEntryTableAdapter3
            // 
            this.assetSoftwareEntryTableAdapter3.ClearBeforeFill = true;
            // 
            // Entries
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.ClientSize = new System.Drawing.Size(1311, 600);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.domainDataGridView);
            this.Controls.Add(this.hardwareEntryDataGridView);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.assetSoftwareEntryDataGridView);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.panel1);
            this.Name = "Entries";
            this.Text = "Entries";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Entries_FormClosing);
            this.Load += new System.EventHandler(this.Entries_Load);
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryBindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalDSBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalDS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.softEntryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.softEntry)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.entriesSetBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.entriesSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryDataSet3BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryDataSet3)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assetSoftwareEntryBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareEntryDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareEntryBindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalDSBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareEntryBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.entriesSetBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareEntryBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hEntryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hEntry)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareEntryBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareEntryfinishBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareEntryfinish)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareEntryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareDataSetFinal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalDSBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.entriesSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hardwareEntryBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.DataGridView assetSoftwareEntryDataGridView;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button5;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.BindingSource assetSoftwareEntryBindingSource3;
        private System.Windows.Forms.BindingSource assetSoftwareEntryDataSet3BindingSource;
        private AssetSoftwareEntryDataSet3 assetSoftwareEntryDataSet3;
        private System.Windows.Forms.BindingSource assetSoftwareEntryBindingSource2;
        private System.Windows.Forms.BindingSource assetSoftwareEntryBindingSource4;
        private AssetSoftwareEntryDataSet3TableAdapters.AssetSoftwareEntryTableAdapter assetSoftwareEntryTableAdapter2;
        private System.Windows.Forms.DataGridView hardwareEntryDataGridView;
        private hardwareDataSetFinal hardwareDataSetFinal;
        private System.Windows.Forms.BindingSource hardwareEntryBindingSource;
        private hardwareDataSetFinalTableAdapters.HardwareEntryTableAdapter hardwareEntryTableAdapter;
        private System.Windows.Forms.DataGridView domainDataGridView;
        private DomainDataSet domainDataSet;
        private System.Windows.Forms.BindingSource domainBindingSource;
        private DomainDataSetTableAdapters.DomainTableAdapter domainTableAdapter;
        private hardwareEntryfinish hardwareEntryfinish;
        private System.Windows.Forms.BindingSource hardwareEntryBindingSource1;
        private hardwareEntryfinishTableAdapters.HardwareEntryTableAdapter hardwareEntryTableAdapter1;
        private System.Windows.Forms.BindingSource hardwareEntryBindingSource2;
        private System.Windows.Forms.BindingSource hardwareEntryfinishBindingSource;
        private System.Windows.Forms.BindingSource hEntryBindingSource;
        private HEntry hEntry;
        private System.Windows.Forms.BindingSource hardwareEntryBindingSource3;
        private HEntryTableAdapters.HardwareEntryTableAdapter hardwareEntryTableAdapter2;
        private System.Windows.Forms.BindingSource entriesSetBindingSource;
        private EntriesSet entriesSet;
        private System.Windows.Forms.BindingSource domainBindingSource1;
        private EntriesSetTableAdapters.DomainTableAdapter domainTableAdapter1;
        private System.Windows.Forms.BindingSource entriesSetBindingSource1;
        private System.Windows.Forms.BindingSource hardwareEntryBindingSource4;
        private EntriesSetTableAdapters.HardwareEntryTableAdapter hardwareEntryTableAdapter3;
        private System.Windows.Forms.BindingSource entriesSetBindingSource2;
        private System.Windows.Forms.BindingSource assetSoftwareEntryBindingSource;
        private EntriesSetTableAdapters.AssetSoftwareEntryTableAdapter assetSoftwareEntryTableAdapter;
        private System.Windows.Forms.BindingSource softEntryBindingSource;
        private softEntry softEntry;
        private System.Windows.Forms.BindingSource assetSoftwareEntryBindingSource1;
        private softEntryTableAdapters.AssetSoftwareEntryTableAdapter assetSoftwareEntryTableAdapter1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.BindingSource finalDSBindingSource;
        private FinalDS finalDS;
        private System.Windows.Forms.BindingSource hardwareEntryBindingSource5;
        private FinalDSTableAdapters.HardwareEntryTableAdapter hardwareEntryTableAdapter4;
        private System.Windows.Forms.DataGridViewTextBoxColumn companyNameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn usernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pCTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn makeAndModelDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn systemConfigDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn monitorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn printerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn oSDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iPAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn assetIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn softwareTypeDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn departmentDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn locationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn remarksDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn printerNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource finalDSBindingSource1;
        private System.Windows.Forms.BindingSource domainBindingSource2;
        private FinalDSTableAdapters.DomainTableAdapter domainTableAdapter2;
        private System.Windows.Forms.DataGridViewTextBoxColumn companyNameDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn registrantNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn creationDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn expiryDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn renewalDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bookedWithDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn domainUsedDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn remarksDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource finalDSBindingSource2;
        private System.Windows.Forms.BindingSource assetSoftwareEntryBindingSource5;
        private FinalDSTableAdapters.AssetSoftwareEntryTableAdapter assetSoftwareEntryTableAdapter3;
        private System.Windows.Forms.DataGridViewTextBoxColumn srNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn companyNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn softwareTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn assetsDescriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn supplierDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn authorizationNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn assetNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn poNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn invNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn softwareAssuranceDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn licenseTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn poDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn invDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn remarksDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn licenseNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn licenseDateDataGridViewTextBoxColumn;
    }
}