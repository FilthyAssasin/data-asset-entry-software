﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Tracing;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Assets_Software_Entry
{
    public partial class Form1 : Form
    {

        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\AssetSoftwareEntry.mdf;Integrated Security=True";

        string fromType;

        public string formType 
        {
            get { return fromType; } 
            set { fromType = value; } 
        }

        public Form1()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'finalDS.AssetSoftwareEntry' table. You can move, or remove it, as needed.
            this.assetSoftwareEntryTableAdapter5.Fill(this.finalDS.AssetSoftwareEntry);

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }


            

        private void label3_Click(object sender, EventArgs e)
        {

        }


        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Entries ss = new Entries("Software");
            ss.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Clear();
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            {
                SqlConnection con = new SqlConnection(connectionString);
                string sTypeEntry = "";
                foreach (string s in checkedListBox1.CheckedItems)
                {
                    if (s == "ADOBE")
                    {
                        sTypeEntry = sTypeEntry + s + "_" + textBox10.Text.Trim() + "_" + dateTimePicker4.Value.ToString("dd-MM-yyyy") + ",";
                    }
                    else
                    {
                        sTypeEntry = sTypeEntry + s + ",";
                    }
                }
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;


                cmd.CommandText = "INSERT INTO AssetSoftwareEntry([Software Type],[Assets Description],[Qty],[Supplier],[Authorization Number],[Asset Number],[Po Number],[Inv Number],[Software Assurance Date],[License Type],[Po Date],[Inv Date],[Company Name],[Remarks],[License Number],[License Date]) VALUES ('" + sTypeEntry + "','" + textBox6.Text.Trim() + "','" + textBox8.Text.Trim() + "','" + textBox4.Text.Trim() + "','" + textBox3.Text.Trim() + "','" + textBox2.Text.Trim() + "','" + textBox5.Text.Trim() + "','" + textBox7.Text.Trim() + "','" + dateTimePicker3.Value.ToString("yyyy-MM-dd") + "','" + comboBox2.SelectedItem + "','" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "','" + dateTimePicker2.Value.ToString("yyyy-MM-dd") + "','" + textBox1.Text.Trim() + "','" + textBox11.Text.Trim() + "','" + textBox13.Text.Trim() + "','" + dateTimePicker5.Value.ToString("yyyy-MM-dd") + "')";
                cmd.CommandTimeout = 60;

                            
                try
                {
                    con.Open();
                    Clear();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Entry Submitted!");
                }
                catch (Exception ec)
                {
                    MessageBox.Show("Error! contact developer");
                    con.Close();

                }

                this.assetSoftwareEntryTableAdapter5.Fill(this.finalDS.AssetSoftwareEntry);
            }

        }
        private void Clear()
        {
            textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = textBox5.Text = textBox6.Text = textBox7.Text = textBox8.Text = textBox10.Text = textBox11.Text = textBox13.Text = "";
            comboBox2.Text = "";
            label2.Visible = label7.Visible = textBox10.Visible = dateTimePicker4.Visible = false;
            for (int i = 0; i < checkedListBox1.Items.Count; i++)
            {
                checkedListBox1.SetItemChecked(i, false);
            }

            label2.Visible = false;
            textBox10.Visible = false;
            label7.Visible = false;
            dateTimePicker4.Visible = false;
            groupBox1.Visible = false;

            textBox6.Location = new Point(219, 128);
            textBox8.Location = new Point(219, 223);
            label4.Location = new Point(21, 163);
            label5.Location = new Point(21, 225);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if(button5.Text.ToString() == "Edit Entries")
            {
                button4.Visible = false;
                button6.Visible = false; 
                button7.Visible = false;
                button2.Visible = true;
                label1.Visible = true;
                comboBox4.Visible = true;
                button5.Text = "Exit Editing";
                Clear();
            }
            else if(button5.Text.ToString() == "Exit Editing")
            {
                button4.Visible = true;
                button6.Visible = true;
                button7.Visible = true;
                button2.Visible = false;
                label1.Visible = false;
                comboBox4.Visible = false;
                button9.Visible = false;
                comboBox4.Text = "";
                textBox9.Visible = false;
                button8.Visible = false;
                button1.Visible = false;
                label1.Text = "Search for :";
                button5.Text = "Edit Entries";
                button8.Text = "Search";
                textBox9.Text = "";

                DataTable dt = new DataTable();
                dt = this.assetSoftwareEntryTableAdapter5.GetData();
                assetSoftwareEntryDataGridView.DataSource = dt;
                Clear();
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            {
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();

                SqlCommand cmd = new SqlCommand("Update AssetSoftwareEntry set [Software Type] = @SoftwareType, [Assets Description] = @AssetsDescription, [Qty] = @Qty, [Supplier] = @Supplier, [Authorization Number] = @AuthorizationNumber, [Asset Number] = @AssetNumber, [Po Number] = @PoNumber, [Inv Number] = @InvNumber, [Software Assurance Date] = @SoftwareAssuranceDate, [License Type] = @LicenseType, [Po Date] = @PoDate, [Inv Date] = @InvDate, [Company Name] = @CompanyName, [Remarks] = @Remarks, [License Number] = @LicenseNumber, [License Date] = @LicenseDate where [" + label1.Text + "] = @Uname", con);



                string sTypeEntry = "";
                foreach (string s in checkedListBox1.CheckedItems)
                {
                    if (s == "ADOBE")
                    {
                        sTypeEntry = sTypeEntry + s + "_" + textBox10.Text.Trim() + "_" + dateTimePicker4.Value.ToString("dd-MM-yyyy") + ",";
                    }
                    else
                    {
                        sTypeEntry = sTypeEntry + s + ",";
                    }
                }
                cmd.Parameters.AddWithValue("@SoftwareType", sTypeEntry);
                cmd.Parameters.AddWithValue("@AssetsDescription", textBox6.Text.Trim());
                cmd.Parameters.AddWithValue("@Qty", textBox8.Text.Trim());
                cmd.Parameters.AddWithValue("@Supplier", textBox4.Text.Trim());
                cmd.Parameters.AddWithValue("@AuthorizationNumber", textBox3.Text.Trim());
                cmd.Parameters.AddWithValue("@AssetNumber", textBox2.Text.Trim());
                cmd.Parameters.AddWithValue("@PoNumber", textBox5.Text.Trim());
                cmd.Parameters.AddWithValue("@InvNumber", textBox7.Text.Trim());
                cmd.Parameters.Add("@SoftwareAssuranceDate", SqlDbType.Date).Value = dateTimePicker3.Value.Date;        
                cmd.Parameters.AddWithValue("@LicenseType", (comboBox2.SelectedItem != null) ? comboBox2.SelectedItem : "");
                cmd.Parameters.Add("@PoDate", SqlDbType.Date).Value = dateTimePicker1.Value.Date;
                cmd.Parameters.Add("@InvDate", SqlDbType.Date).Value = dateTimePicker2.Value.Date;
                cmd.Parameters.AddWithValue("@CompanyName", textBox1.Text.Trim());
                cmd.Parameters.AddWithValue("@Uname", textBox9.Text.Trim());
                cmd.Parameters.AddWithValue("@Remarks", textBox11.Text.Trim());
                cmd.Parameters.AddWithValue("@LicenseNumber", textBox13.Text.Trim());
                cmd.Parameters.Add("@LicenseDate", SqlDbType.Date).Value = dateTimePicker5.Value.Date;

                Clear();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Entry was successfully edited!");

                DataTable dt = new DataTable();
                dt = this.assetSoftwareEntryTableAdapter5.GetDataSr(Int16.Parse(textBox9.Text));
                assetSoftwareEntryDataGridView.DataSource = dt;
            }       
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (textBox9.Text.Trim() != "")
            {

                if (button8.Text == "Search")
                {
                    if (label1.Text == comboBox4.Items[0].ToString())
                    {
                        DataTable dt = this.assetSoftwareEntryTableAdapter5.GetDataByCom(textBox9.Text.Trim());
                        assetSoftwareEntryDataGridView.DataSource = dt;
                    }
                    else if (label1.Text == comboBox4.Items[1].ToString())
                    {
                        DataTable dt = this.assetSoftwareEntryTableAdapter5.GetDataByAuth(textBox9.Text.Trim());
                        assetSoftwareEntryDataGridView.DataSource = dt;
                    }
                    else if (label1.Text == comboBox4.Items[2].ToString())
                    {
                        DataTable dt = this.assetSoftwareEntryTableAdapter5.GetDataAsset(textBox9.Text.Trim());
                        assetSoftwareEntryDataGridView.DataSource = dt;
                    }

                    label1.Text = "Sr. No.";
                    button8.Text = "Edit";
                    textBox9.Text = "";

                }

                else if (button8.Text == "Edit")
                {
                    Clear();
                    DataTable dt = new DataTable();
                    try
                    {
                        dt = this.assetSoftwareEntryTableAdapter5.GetDataSr(Int16.Parse(textBox9.Text.Trim()));
                        assetSoftwareEntryDataGridView.DataSource = dt;
                        
                    }
                    catch(Exception ec)
                    {
                        MessageBox.Show(ec.Message);                
                    }

                    try
                    {
                        textBox1.Text = dt.Rows[0][1].ToString();
                        int i = 0;
                        while (!String.IsNullOrEmpty(dt.Rows[0][2].ToString().Split(',')[i]))
                        {
                            if (dt.Rows[0][2].ToString().Split(',')[i].Contains("ADOBE"))
                            {
                                checkedListBox1.SetItemChecked(1, true);
                                textBox10.Text = dt.Rows[0][2].ToString().Split(',')[i].ToString().Split('_')[1];
                                dateTimePicker4.Value = Convert.ToDateTime(dt.Rows[0][2].ToString().Split(',')[i].ToString().Split('_')[2]);
                                label2.Visible = true;
                                textBox10.Visible = true;
                                label7.Visible = true;
                                dateTimePicker4.Visible = true;
                                groupBox1.Visible = true;

                                textBox6.Location = new Point(219, 169);
                                textBox8.Location = new Point(219, 265);
                                label4.Location = new Point(21, 211);
                                label5.Location = new Point(21, 267);
                            }
                            else if (dt.Rows[0][2].ToString().Split(',')[i].Contains("OFFICE"))
                            {
                                checkedListBox1.SetItemChecked(0, true);
                            }
                            else if (dt.Rows[0][2].ToString().Split(',')[i].Contains("AUTO"))
                            {
                                checkedListBox1.SetItemChecked(2, true);
                            }
                            else if (dt.Rows[0][2].ToString().Split(',')[i].Contains("CORAL"))
                            {
                                checkedListBox1.SetItemChecked(3, true);
                            }
                            else if (dt.Rows[0][2].ToString().Split(',')[i].Contains("WINDOWS"))
                            {
                                checkedListBox1.SetItemChecked(4, true);
                            }
                            else if (dt.Rows[0][2].ToString().Split(',')[i].Contains("CAL"))
                            {
                                checkedListBox1.SetItemChecked(5, true);
                            }
                            else if (dt.Rows[0][2].ToString().Split(',')[i].Contains("WPS Office"))
                            {
                                checkedListBox1.SetItemChecked(6, true);
                            }
                            else if (dt.Rows[0][2].ToString().Split(',')[i].Contains("Solidworks Pro"))
                            {
                                checkedListBox1.SetItemChecked(7, true);
                            }
                            i++;
                        }

                        textBox6.Text = dt.Rows[0][3].ToString();
                        textBox8.Text = dt.Rows[0][4].ToString();
                        textBox4.Text = dt.Rows[0][5].ToString();
                        textBox3.Text = dt.Rows[0][6].ToString();
                        textBox2.Text = dt.Rows[0][7].ToString();
                        textBox5.Text = dt.Rows[0][8].ToString();
                        textBox7.Text = dt.Rows[0][9].ToString();
                        dateTimePicker3.Value.Date.ToString().Split()[0] = dt.Rows[0][10].ToString();
                        comboBox2.Text = dt.Rows[0][11].ToString();
                        dateTimePicker1.Value.Date.ToString().Split()[0] = dt.Rows[0][12].ToString();
                        dateTimePicker2.Value.Date.ToString().Split()[0] = dt.Rows[0][13].ToString();
                        textBox11.Text = dt.Rows[0][14].ToString();
                        textBox13.Text = dt.Rows[0][15].ToString();
                        dateTimePicker5.Value.Date.ToString().Split()[0] = dt.Rows[0][16].ToString();
                    }
                    catch(Exception ec)
                    {
                        MessageBox.Show("No such entry");
                    }

                }

            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox4.Visible = false;
            textBox9.Visible = true;
            button8.Visible = true;
            button1.Visible = true;
            button9.Visible = true;
            label1.Text = comboBox4.SelectedItem.ToString();
            textboxchange();
        }       

        private void button1_Click(object sender, EventArgs e)
        {
            comboBox4.Text = "";
            comboBox4.Visible = true;
            textBox9.Visible = false;
            button8.Visible = false;
            button8.Text = "Search";
            textBox9.Text = "";
            button9.Visible = false;
            button1.Visible = false;
            label1.Text = "Search for :";
            Clear();
            DataTable dt = new DataTable();
            dt = this.assetSoftwareEntryTableAdapter5.GetData();
            assetSoftwareEntryDataGridView.DataSource = dt;
        }

        private void assetSoftwareEntryBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.assetSoftwareEntryBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.assetSoftwareEntry);
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }


        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            textboxchange();
        }

        private void textBox8_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textboxchange();
            }
        }
        public void textboxchange()
        {
            SendKeys.SendWait("{TAB }");
        }

        private void textBox7_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textboxchange();
            }
        }

        private void textBox6_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textboxchange();
            }
        }

        private void textBox5_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textboxchange();
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textboxchange();
            }
        }

        private void textBox4_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textboxchange();
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textboxchange();
            }
        }

        private void textBox3_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textboxchange();
            }       
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            textboxchange();
        }

        private void dateTimePicker4_ValueChanged(object sender, EventArgs e)
        {
            textboxchange();
        }

        private void dateTimePicker3_ValueChanged(object sender, EventArgs e)
        {
            textboxchange();
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            textboxchange();
        }

        private void assetSoftwareEntryDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            textboxchange();
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox10_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                textboxchange();                
            }
        }


        private void dateTimePicker4_ValueChanged_1(object sender, EventArgs e)
        {
            textboxchange();
        }

        private void fillBySrToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
            }       
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void textBox1_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textboxchange();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Select ss = new Select();
            this.Hide();
            ss.ShowDialog();
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textboxchange();

            bool isAdobe = false;

            foreach (string s in checkedListBox1.CheckedItems)
            {
                if (s == "ADOBE")
                {
                    isAdobe = true;
                }
            }

            if (isAdobe)
            {
                label2.Visible = true;
                textBox10.Visible = true;
                label7.Visible = true;
                dateTimePicker4.Visible = true;
                groupBox1.Visible = true;
                textBox6.Location = new Point(219,169);
                textBox8.Location = new Point(219, 265);
                label4.Location = new Point(21, 211);
                label5.Location = new Point(21, 267);
            }
            else
            {
                label2.Visible = false;
                textBox10.Visible = false;
                label7.Visible = false;
                dateTimePicker4.Visible = false;
                groupBox1.Visible = false;
                textBox6.Location = new Point(219, 128);
                textBox8.Location = new Point(219, 223);
                label4.Location = new Point(21, 163);
                label5.Location = new Point(21, 225);
                textBox10.Text = "";
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if(textBox9.Text != "")
            {
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand("delete from AssetSoftwareEntry where [" + label1.Text + "]='" + textBox9.Text.Trim() + "'", con);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Entry Successfully deleted!");
                    con.Close();
                    DataTable dt = this.assetSoftwareEntryTableAdapter5.GetData();
                    assetSoftwareEntryDataGridView.DataSource = dt;
                }
                catch (Exception ec)
                {
                    MessageBox.Show(ec.Message);
                    con.Close();
                }
            }
            else
            {
                MessageBox.Show("Please specify entry you want to delete");
            }
            
        }

    }
}
