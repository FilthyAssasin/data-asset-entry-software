﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Assets_Software_Entry
{
    public partial class Domain : Form
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\AssetSoftwareEntry.mdf;Integrated Security=True";

        
        public Domain()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void domainBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.domainBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.domainDataSet);

        }

        private void Domain_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'finalDS.Domain' table. You can move, or remove it, as needed.
            this.domainTableAdapter2.Fill(this.finalDS.Domain);
        }

        private void Clear()
        {
            textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = textBox5.Text = textBox6.Text = "";
        }
        public void textboxchange()
        {
            SendKeys.SendWait("{TAB }");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            {
                SqlConnection con = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand("INSERT INTO Domain([Company Name],[Name],[Creation Date],[Expiry Date],[Renewal Date],[Booked With],[Registrant Name],[Domain Used],[Remarks]) VALUES ('" + textBox1.Text.Trim() + "','" + textBox2.Text.Trim() + "','" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "','" + dateTimePicker2.Value.ToString("yyyy-MM-dd") + "','" + dateTimePicker3.Value.ToString("yyyy-MM-dd") + "','" + textBox3.Text.Trim() + "','" + textBox4.Text.Trim() + "','" + textBox5.Text.Trim() + "','" + textBox6.Text.Trim() + "')", con);
                cmd.CommandTimeout = 60;

                try
                {
                    con.Open();
                    Clear();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Successfully Submitted");
                }
                catch (Exception ec)
                {
                    MessageBox.Show(ec.Message);
                    MessageBox.Show("error");
                    con.Close();

                }

                DataTable dt = this.domainTableAdapter2.GetData();
                domainDataGridView.DataSource = dt;

            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (button5.Text.ToString() == "Edit Entries")
            {
                button4.Visible = false;
                button6.Visible = false;
                button7.Visible = false;
                button2.Visible = true;
                label1.Visible = true;
                comboBox6.Visible = true;
                button5.Text = "Exit Editing";
            }
            else if (button5.Text.ToString() == "Exit Editing")
            {
                button4.Visible = true;
                button6.Visible = true;
                button7.Visible = true;
                button2.Visible = false;
                button9.Visible = false;
                label1.Visible = false;
                comboBox6.Visible = false;
                comboBox6.Text = "";
                textBox9.Visible = false;
                button8.Visible = false;
                button1.Visible = false;
                label1.Text = "Search for :";
                button5.Text = "Edit Entries";

                DataTable dt = this.domainTableAdapter2.GetData();
                domainDataGridView.DataSource = dt;
            }
        }

        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            button9.Visible = true;
            textBox9.Visible = true;
            textboxchange();
            comboBox6.Visible = false;
            button8.Visible = true;
            button1.Visible = true;
            label1.Text = comboBox6.SelectedItem.ToString();
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (textBox9.Text != "")
            {
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                DataTable dt = new DataTable();

                if (label1.Text == "Domain Name")
                {
                    SqlDataAdapter sda = new SqlDataAdapter("select * from Domain where [" + label1.Text.Split()[1] + "] = '" + textBox9.Text.Trim() + "'", con);
                    sda.Fill(dt);

                }
                else
                {
                    SqlDataAdapter sda = new SqlDataAdapter("select * from Domain where [" + label1.Text + "] = '" + textBox9.Text.Trim() + "'", con);
                    sda.Fill(dt);
                }
               
                try
                {
                    domainDataGridView.DataSource = dt;
                    textBox1.Text = dt.Rows[0][0].ToString();
                    textBox2.Text = dt.Rows[0][1].ToString();
                    textBox4.Text = dt.Rows[0][2].ToString();
                    dateTimePicker1.Value = Convert.ToDateTime(dt.Rows[0][3].ToString());
                    dateTimePicker2.Value = Convert.ToDateTime(dt.Rows[0][4].ToString());
                    dateTimePicker3.Value = Convert.ToDateTime(dt.Rows[0][5].ToString());
                    textBox3.Text = dt.Rows[0][6].ToString();
                    textBox5.Text = dt.Rows[0][7].ToString();
                    textBox6.Text = dt.Rows[0][8].ToString();

                    con.Close();
                }
                catch (Exception ec)
                {
                    MessageBox.Show("No such Entry");
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            comboBox6.Text = "";
            comboBox6.Visible = true;
            textBox9.Visible = false;
            button8.Visible = false;
            button1.Visible = false;
            button9.Visible = false;
            label1.Text = "Search for :";
            textBox9.Text = "";
            DataTable dt = this.domainTableAdapter2.GetData();
            domainDataGridView.DataSource = dt;
            Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            {
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();

                SqlCommand cmd = new SqlCommand("Update Domain set [Company Name] = @CompanyName, [Name] = @Name, [Creation Date] = @CreationDate, [Expiry Date] = @ExpiryDate, [Renewal Date] = @RenewalDate, [Booked With] = @BookedWith, [Registrant Name] = @RegistrantName, [Domain Used] = @DomainUsed, [Remarks] = @Remarks where [" + label1.Text + "] = @Uname", con);

                cmd.Parameters.AddWithValue("@CompanyName", textBox1.Text.Trim());
                cmd.Parameters.AddWithValue("@Name", textBox2.Text.Trim());
                cmd.Parameters.Add("@CreationDate", SqlDbType.Date).Value = dateTimePicker1.Value.Date;
                cmd.Parameters.Add("@ExpiryDate", SqlDbType.Date).Value = dateTimePicker2.Value.Date;
                cmd.Parameters.AddWithValue("@BookedWith", textBox3.Text.Trim());
                cmd.Parameters.Add("@RenewalDate", SqlDbType.Date).Value = dateTimePicker3.Value.Date;
                cmd.Parameters.AddWithValue("@RegistrantName", textBox4.Text.Trim());
                cmd.Parameters.AddWithValue("@DomainUsed", textBox5.Text.Trim());
                cmd.Parameters.AddWithValue("@Uname", textBox9.Text.Trim());
                cmd.Parameters.AddWithValue("@Remarks", textBox6.Text.Trim());

                cmd.ExecuteNonQuery();
                con.Close();
                Clear();
                textBox9.Text = "";

                MessageBox.Show("Entry was successfully edited!");

                DataTable dt = this.domainTableAdapter2.GetData();
                domainDataGridView.DataSource = dt;
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textboxchange();
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textboxchange();
            }
        }

        private void textBox3_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textboxchange();
            }
        }

        private void textBox5_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textboxchange();
            }
        }

        private void textBox4_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textboxchange();
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            textboxchange();
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            textboxchange();
        }

        private void dateTimePicker3_ValueChanged(object sender, EventArgs e)
        {
            textboxchange();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Entries ss = new Entries("Domain");
            ss.ShowDialog();
            ss.Dispose();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Select ss = new Select();
            this.Hide();
            ss.ShowDialog();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want do delete entries with " + label1.Text + ": " + textBox9.Text.Trim() + "?", "Message", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand();

                if (label1.Text == "Domain Name")
                {
                    cmd.CommandText = "delete from Domain where [" + label1.Text + "]='" + textBox9.Text.Trim() + "'";

                }
                else
                {
                    cmd.CommandText = "delete from Domain where [" + label1.Text + "]='" + textBox9.Text.Trim() + "'";

                }
                cmd.Connection = con;
                try
                {
                    cmd.ExecuteNonQuery();
                    con.Close();
                    DataTable dt = this.domainTableAdapter2.GetData();
                    domainDataGridView.DataSource = dt;
                    MessageBox.Show("Entry Successfully deleted!");

                }
                catch (Exception ec)
                {
                    MessageBox.Show(ec.Message);
                    con.Close();
                }
            }
            
        }
    }
}
