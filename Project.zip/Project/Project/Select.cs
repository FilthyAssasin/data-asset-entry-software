﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assets_Software_Entry
{
    public partial class Select : Form
    {
        public Select()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 ss = new Form1();
            this.Hide();
            ss.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            HardwareEntry ss = new HardwareEntry();
            this.Hide();
            ss.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Domain ss = new Domain();
            this.Hide();
            ss.ShowDialog();
        }

        private void Select_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
