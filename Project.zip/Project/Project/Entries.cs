﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Assets_Software_Entry
{

    public partial class Entries : Form
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\AssetSoftwareEntry.mdf;Integrated Security=True";
        string form;
        public Entries(string formType)
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            form = formType;
            if (form == "Hardware")
            {
                comboBox1.Items.Clear();
                comboBox1.Items.Add("Company Name");
                comboBox1.Items.Add("Username");
                comboBox1.Items.Add("Asset ID");
            }
            else if (form == "Domain")
            {
                comboBox1.Items.Clear();
                comboBox1.Items.Add("Company Name");
                comboBox1.Items.Add("Domain Name");
                comboBox1.Items.Add("Registrant Name");
                comboBox1.Items.Add("Domain Used");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if(form == "Software")
            {
                Form1 ss = new Form1();
                this.Hide();
                ss.ShowDialog();
            }
            else if(form == "Hardware")
            {
                HardwareEntry ss = new HardwareEntry();
                this.Hide();
                ss.ShowDialog();
            }
            else if(form == "Domain")
            {
                Domain ss = new Domain      ();
                this.Hide();
                ss.ShowDialog();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (form == "Software")
            {
                if (label2.Text == comboBox1.Items[0].ToString())
                {
                    DataTable dt = this.assetSoftwareEntryTableAdapter3.GetDataSr(Int16.Parse(textBox5.Text.Trim()));
                    assetSoftwareEntryDataGridView.DataSource = dt;
                }

                else if (label2.Text == comboBox1.Items[1].ToString())
                {
                    DataTable dt = this.assetSoftwareEntryTableAdapter3.GetDataByCom(textBox5.Text.Trim());
                    assetSoftwareEntryDataGridView.DataSource = dt;
                }

                else if (label2.Text == comboBox1.Items[2].ToString())
                {
                    DataTable dt = this.assetSoftwareEntryTableAdapter3.GetDataByAuth(textBox5.Text.Trim());
                    assetSoftwareEntryDataGridView.DataSource = dt;
                }

                else if (label2.Text == comboBox1.Items[3].ToString())
                {
                    DataTable dt = this.assetSoftwareEntryTableAdapter3.GetDataAsset(textBox5.Text.Trim());
                    assetSoftwareEntryDataGridView.DataSource = dt;
                }
            }
            else if (form == "Hardware")
            {
                if (label2.Text == comboBox1.Items[0].ToString())
                {
                    DataTable dt = this.hardwareEntryTableAdapter4.GetDataByCom(textBox5.Text.Trim());
                    hardwareEntryDataGridView.DataSource = dt;
                }

                else if (label2.Text == comboBox1.Items[1].ToString())
                {
                    DataTable dt = this.hardwareEntryTableAdapter4.GetDataByUsername(textBox5.Text.Trim());
                    hardwareEntryDataGridView.DataSource = dt;
                }

                else if (label2.Text == comboBox1.Items[2].ToString())
                {
                    DataTable dt = this.hardwareEntryTableAdapter4.GetDataByID(textBox5.Text.Trim());
                    hardwareEntryDataGridView.DataSource = dt;
                }
            }
            else if (form == "Domain")
            {
                if (label2.Text == comboBox1.Items[0].ToString())
                {
                    DataTable dt = this.domainTableAdapter2.GetDataByCom(textBox5.Text.Trim()); 
                    domainDataGridView.DataSource = dt;
                }

                else if (label2.Text == comboBox1.Items[1].ToString())
                {
                    DataTable dt = this.domainTableAdapter2.GetDataByName(textBox5.Text.Trim());
                    domainDataGridView.DataSource = dt;
                }

                else if (label2.Text == comboBox1.Items[2].ToString())
                {
                    DataTable dt = this.domainTableAdapter2.GetDataByRname(textBox5.Text.Trim());
                    domainDataGridView.DataSource = dt;
                }
                else if (label2.Text == comboBox1.Items[3].ToString())
                {
                    DataTable dt = this.domainTableAdapter2.GetDataByDused(textBox5.Text.Trim());
                    domainDataGridView.DataSource = dt;
                }

            }
        }


        private void Entries_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'finalDS.AssetSoftwareEntry' table. You can move, or remove it, as needed.
            this.assetSoftwareEntryTableAdapter3.Fill(this.finalDS.AssetSoftwareEntry);
            // TODO: This line of code loads data into the 'finalDS.Domain' table. You can move, or remove it, as needed.
            this.domainTableAdapter2.Fill(this.finalDS.Domain);
            // TODO: This line of code loads data into the 'finalDS.HardwareEntry' table. You can move, or remove it, as needed.
            this.hardwareEntryTableAdapter4.Fill(this.finalDS.HardwareEntry);

            if (form == "Software")
            {
                assetSoftwareEntryDataGridView.Visible = true;
            }
            else if (form == "Hardware")
            {
                hardwareEntryDataGridView.Visible = true;
            }
            else if (form == "Domain")
            {
                domainDataGridView.Visible = true;
            }

        }




        private void button4_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want do delete entries with " + label2.Text + ": " + textBox5.Text.Trim() + "?", "Message", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                if (form == "Software")
                {
                    SqlConnection con = new SqlConnection(connectionString);
                    con.Open();
                    SqlCommand cmd = new SqlCommand("delete from AssetSoftwareEntry where [" + label2.Text + "]='" + textBox5.Text.Trim() + "'", con);

                    try
                    {
                        cmd.ExecuteNonQuery();
                        con.Close();
                        DataTable dt = this.assetSoftwareEntryTableAdapter3.GetData();
                        assetSoftwareEntryDataGridView.DataSource = dt;
                        MessageBox.Show("Entry Successfully deleted!");

                    }
                    catch (Exception ec)
                    {
                        MessageBox.Show(ec.Message);
                        con.Close();
                    }
                }
                else if (form == "Hardware")
                {
                    SqlConnection con = new SqlConnection(connectionString);
                    con.Open();
                    SqlCommand cmd = new SqlCommand("delete from HardwareEntry where [" + label2.Text + "]='" + textBox5.Text.Trim() + "'", con);

                    try
                    {
                        cmd.ExecuteNonQuery();
                        con.Close();
                        DataTable dt = this.hardwareEntryTableAdapter4.GetData();
                        hardwareEntryDataGridView.DataSource = dt;
                        MessageBox.Show("Entry Successfully deleted!");

                    }
                    catch (Exception ec)
                    {
                        MessageBox.Show(ec.Message);
                        con.Close();
                    }
                }
                else if (form == "Domain")
                {
                    SqlConnection con = new SqlConnection(connectionString);
                    con.Open();
                    SqlCommand cmd = new SqlCommand();

                    if (label2.Text == "Domain Name")
                    {
                        cmd.CommandText = "delete from Domain where [" + label2.Text.Split()[1] + "]='" + textBox5.Text.Trim() + "'";

                    }
                    else
                    {
                        cmd.CommandText = "delete from Domain where [" + label2.Text + "]='" + textBox5.Text.Trim() + "'";

                    }
                    cmd.Connection = con;
                    try
                    {
                        cmd.ExecuteNonQuery();
                        con.Close();
                        DataTable dt = this.domainTableAdapter2.GetData();
                        domainDataGridView.DataSource = dt;
                        MessageBox.Show("Entry Successfully deleted!");

                    }
                    catch (Exception ec)
                    {
                        MessageBox.Show(ec.Message);
                        con.Close();
                    }
                }
            }
            
            

        }



        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            label2.Text = comboBox1.SelectedItem.ToString();
            comboBox1.Visible = false;
            textBox5.Visible = true;
            
            button2.Visible = true;
            button1.Visible = true;
            button4.Visible = true;
        }       

        private void button1_Click_1(object sender, EventArgs e)
        {
            comboBox1.Text = "";
            comboBox1.Visible = true;
            textBox5.Visible = false;
            button4.Visible = false;
            button2.Visible = false;
            button1.Visible = false;
            textBox5.Text = "";
            label2.Text = "Search for :";

            if (form == "Software")
            {
                DataTable dt = this.assetSoftwareEntryTableAdapter3.GetData();
                assetSoftwareEntryDataGridView.DataSource = dt;
            }
            else if (form == "Hardware")
            {
                DataTable dt = this.hardwareEntryTableAdapter4.GetData();
                hardwareEntryDataGridView.DataSource = dt;
            }
            else if (form == "Domain")
            {
                DataTable dt = this.domainTableAdapter2.GetData();
                domainDataGridView.DataSource = dt;
            }
            

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if (form == "Software")
            {
                Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel.Workbook workbook = app.Workbooks.Add(Type.Missing);
                Microsoft.Office.Interop.Excel.Worksheet worksheet = null;
                worksheet = workbook.Sheets["Sheet1"];
                worksheet = workbook.ActiveSheet;
                worksheet.Name = "AssetSoftwareEntry";

                for (int i = 1; i < assetSoftwareEntryDataGridView.Columns.Count + 1; i++)
                {
                    worksheet.Cells[1, i] = assetSoftwareEntryDataGridView.Columns[i - 1].HeaderText;
                }

                for (int j = 0; j < assetSoftwareEntryDataGridView.Rows.Count; j++)
                {
                    for (int k = 0; k < assetSoftwareEntryDataGridView.Columns.Count; k++)
                    {
                        worksheet.Cells[j + 2, k + 1] = assetSoftwareEntryDataGridView.Rows[j].Cells[k].Value.ToString();
                    }
                }

                var saveFileDialogue = new SaveFileDialog();
                saveFileDialogue.FileName = "Output";
                saveFileDialogue.DefaultExt = ".xlsx";
                if (saveFileDialogue.ShowDialog() == DialogResult.OK)
                {
                    workbook.SaveAs(saveFileDialogue.FileName, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                }
                app.Quit();
                MessageBox.Show("Succesfully Saved");
            }
            else if (form == "Hardware")
            {
                Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel.Workbook workbook = app.Workbooks.Add(Type.Missing);
                Microsoft.Office.Interop.Excel.Worksheet worksheet = null;
                worksheet = workbook.Sheets["Sheet1"];
                worksheet = workbook.ActiveSheet;
                worksheet.Name = "HardwareEntry";

                for (int i = 1; i < hardwareEntryDataGridView.Columns.Count + 1; i++)
                {
                    worksheet.Cells[1, i] = hardwareEntryDataGridView.Columns[i - 1].HeaderText;
                }

                for (int j = 0; j < hardwareEntryDataGridView.Rows.Count; j++)
                {
                    for (int k = 0; k < hardwareEntryDataGridView.Columns.Count; k++)
                    {
                        worksheet.Cells[j + 2, k + 1] = hardwareEntryDataGridView.Rows[j].Cells[k].Value.ToString();
                    }
                }

                var saveFileDialogue = new SaveFileDialog();
                saveFileDialogue.FileName = "Output";
                saveFileDialogue.DefaultExt = ".xlsx";
                if (saveFileDialogue.ShowDialog() == DialogResult.OK)
                {
                    workbook.SaveAs(saveFileDialogue.FileName, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                }
                app.Quit();
                MessageBox.Show("Succesfully Saved");
            }
            else if (form == "Domain")
            {
                Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel.Workbook workbook = app.Workbooks.Add(Type.Missing);
                Microsoft.Office.Interop.Excel.Worksheet worksheet = null;
                worksheet = workbook.Sheets["Sheet1"];
                worksheet = workbook.ActiveSheet;
                worksheet.Name = "DomainEntry";

                for (int i = 1; i < domainDataGridView.Columns.Count + 1; i++)
                {
                    worksheet.Cells[1, i] = domainDataGridView.Columns[i - 1].HeaderText;
                }

                for (int j = 0; j < domainDataGridView.Rows.Count; j++)
                {
                    for (int k = 0; k < domainDataGridView.Columns.Count; k++)
                    {
                        worksheet.Cells[j + 2, k + 1] = domainDataGridView.Rows[j].Cells[k].Value.ToString();
                    }
                }

                var saveFileDialogue = new SaveFileDialog();
                saveFileDialogue.FileName = "Output";
                saveFileDialogue.DefaultExt = ".xlsx";
                if (saveFileDialogue.ShowDialog() == DialogResult.OK)
                {
                    workbook.SaveAs(saveFileDialogue.FileName, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                }
                app.Quit();
                MessageBox.Show("Succesfully Saved");
            }
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (form == "Software")
            {
                Report report = new Report();
                report.ShowDialog();
                report.Dispose();
            }
            else if (form == "Hardware")
            {
                ReportH report = new ReportH();
                report.ShowDialog();
                report.Dispose();
            }
            else if (form == "Domain")
            {
                ReportD report = new ReportD();
                report.ShowDialog();
                report.Dispose();
            }
            
        }

        private void Entries_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
        }
    }
}
