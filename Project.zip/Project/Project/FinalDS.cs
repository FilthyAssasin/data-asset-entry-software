﻿namespace Assets_Software_Entry
{


    partial class FinalDS
    {
    }
}

namespace Assets_Software_Entry.FinalDSTableAdapters {
    
    
    public partial class DomainTableAdapter {
    }
}
