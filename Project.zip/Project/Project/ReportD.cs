﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace Assets_Software_Entry
{
    public partial class ReportD : Form
    {
        ReportDocument rep = new ReportDocument();
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\AssetSoftwareEntry.mdf;Integrated Security=True";
        public ReportD()
        {
            InitializeComponent();
        }

        private void ReportD_Load(object sender, EventArgs e)
        {
            string filename = @"CrystalReport3.rpt";
            string filePath = AppDomain.CurrentDomain.BaseDirectory + filename;
            rep.Load(@"" + filePath + "");
            TableLogOnInfos tableLogOnInfos = new TableLogOnInfos();
            TableLogOnInfo tableLogOnInfo = new TableLogOnInfo();
            ConnectionInfo connectionInfo = new ConnectionInfo();
            Tables tables;

            connectionInfo.ServerName = @"(LocalDB)\MSSQLLocalDB";
            connectionInfo.DatabaseName = "AssetSoftwareEntry";
            connectionInfo.UserID = @"LAPTOP-MCM75Q33\karan";
            connectionInfo.Password = "";

            tables = rep.Database.Tables;

            foreach (CrystalDecisions.CrystalReports.Engine.Table table in tables)
            {
                tableLogOnInfo = table.LogOnInfo;
                tableLogOnInfo.ConnectionInfo = connectionInfo;
                table.ApplyLogOnInfo(tableLogOnInfo);
            }

            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter("select * from Domain", con);
            DataSet ds = new System.Data.DataSet();
            sda.Fill(ds, "Domain");
            rep.SetDataSource(ds);
            crystalReportViewer1.ReportSource = rep;
        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}
