﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;
using System.Data.SqlClient;
using System.Configuration;

namespace Assets_Software_Entry
{
    public partial class Login : Form
    {

        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\AssetSoftwareEntry.mdf;Integrated Security=True";
        int mouseX = 0;
        int mouseY = 0;
        bool mouseDown;

        public Login()
        {
            InitializeComponent();
        }
        public void textboxchange()
        {
            SendKeys.SendWait("{TAB }");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            signupPanel.Left = 160;
            loginPanel.Left = 500;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            signupPanel.Left = 500;
            loginPanel.Left = 177;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter sda = new SqlDataAdapter("select Username, Password from users",con);

            DataTable dt = new DataTable();
            sda.Fill(dt);
            bool isUser = false;
            string user = "";

            if(textBox1.Text.Trim() != "" && textBox2.Text.Trim() != "")
            {
                foreach (DataRow row in dt.Rows)
                {
                    if (row[0].ToString() == textBox1.Text)
                    {
                        foreach (DataColumn col in dt.Columns)
                        {
                            if (row[col].ToString() == textBox2.Text)
                            {
                                isUser = true;
                                user += row[0].ToString();
                            }
                        }
                    }
                }

                if (isUser)
                {
                    this.Hide();

                    Select ss = new Select();
                    ss.ShowDialog();
                    MessageBox.Show("Welcome " + user + "!");
                }

                else
                {
                    MessageBox.Show("Wrong Username or Password!");
                }
            }
            else
            {
                MessageBox.Show("Please fill Username and Password");
            }
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox3.Text.Trim() != "" && textBox4.Text.Trim() != "" && textBox5.Text.Trim() != "" && textBox6.Text.Trim() != "")
            {
                bool acceptableLength = true;
                int count = 0;
                foreach(char c in textBox4.Text.ToString())
                {
                    count++;
                }
                if (count < 8 || count > 20)
                {
                    acceptableLength = false;
                    MessageBox.Show("Password should be between 8 to 20 characters long");
                }

                if (acceptableLength)
                {
                    bool email = true;
                    try
                    {
                        MailAddress m = new MailAddress(textBox6.Text.Trim());
                    }
                    catch (FormatException)
                    {
                        email = false;
                    }
                    
                    if (email)
                    {
                        SqlConnection con = new SqlConnection(connectionString);
                        con.Open();

                        SqlCommand cmd = new SqlCommand("INSERT INTO users([Username],[Full Name],[Email],[Password]) VALUES(@Username,@Fullname,@Email,@Password)",con);
                        cmd.Parameters.AddWithValue("@Username", textBox5.Text);
                        cmd.Parameters.AddWithValue("@Fullname", textBox3.Text);
                        cmd.Parameters.AddWithValue("@Email", textBox6.Text);
                        cmd.Parameters.AddWithValue("@Password", textBox4.Text);
                        
                        try
                        {
                            try
                            {
                                cmd.ExecuteNonQuery();
                                con.Close();
                            }
                            catch (Exception ec)
                            {
                                MessageBox.Show("Username already exists. Please use another username!");
                                con.Close();
                            }

                            var mailhelp = new EmailRegister();
                            mailhelp.Send(textBox6.Text);
                            MessageBox.Show("Registration Successful!");
                            signupPanel.Left = 500;
                            loginPanel.Left = 177;
                            Clear();
                        }
                        catch (Exception error)
                        {
                            MessageBox.Show(error.Message);
                            MessageBox.Show("Registration Successful!");
                            signupPanel.Left = 500;
                            loginPanel.Left = 177;
                            Clear();
                        }
                        
                        
                    }
                    else
                    {
                        MessageBox.Show("Invalid Email!");
                    }
                }
            }
            else
            {
                MessageBox.Show("One or more fields are empty!");
            }
            
        }

        public void Clear()
        {
            textBox3.Text = textBox4.Text = textBox5.Text = textBox6.Text = "";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (textBox2.PasswordChar == (char)42)
            {
                textBox2.PasswordChar = (char)0;
            }
            else
            {
                textBox2.PasswordChar = (char)42;
            }
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (textBox4.PasswordChar == (char)42)
            {
                textBox4.PasswordChar = (char)0;
            }
            else
            {
                textBox4.PasswordChar = (char)42;
            }
        }

        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            mouseDown = true;
        }

        private void panel2_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown)
            {
                mouseX = MousePosition.X - 230;
                mouseY = MousePosition.Y - 10;

                this.SetDesktopLocation(mouseX, mouseY);
            }
        }

        private void panel2_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                textboxchange();
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textboxchange();
            }
        }

        private void textBox5_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textboxchange();
            }
        }

        private void textBox3_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textboxchange();
            }
        }

        private void textBox6_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textboxchange();
            }
        }

        private void textBox4_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textboxchange();
            }
        }

    }
}
